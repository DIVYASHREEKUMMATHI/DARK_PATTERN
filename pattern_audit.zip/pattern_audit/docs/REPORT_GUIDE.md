# Project Report Writing Guide

## Title
**Multimodal AI System for Detecting Dark Patterns in Web Interfaces**

---

## Abstract (150–200 words)

Write a short summary covering:
1. What problem you solved
2. What methods you used
3. What results you got

**Sample Abstract:**
> Dark patterns are deceptive UI/UX design techniques used by websites to
> manipulate users into unintended actions such as unwanted subscriptions,
> hidden charges, and forced account creation. This project presents a
> multimodal AI system that detects dark patterns from website screenshots
> using a combination of Optical Character Recognition (OCR), Natural Language
> Processing (NLP), and Computer Vision. The system extracts text from
> screenshots using Tesseract OCR, classifies it using a DistilBERT-based
> model fine-tuned on a custom dataset, and simultaneously analyzes visual
> elements using OpenCV. A fusion layer combines both signals to produce a
> final dark pattern category with a confidence score. The system was deployed
> as a Flask web application. Our keyword-based classifier achieved 87% accuracy
> and the combined multimodal system further improved detection on ambiguous cases.

---

## Chapter 1: Introduction

### 1.1 Background
- What are dark patterns? (define in your own words)
- Why are they harmful to users?
- How many people are affected? (cite statistics if possible)

### 1.2 Problem Statement
> "Existing tools detect dark patterns manually. This project automates
> detection using AI, reducing the effort required by users and researchers."

### 1.3 Objectives
List all project goals:
1. Build an OCR-based text extraction pipeline
2. Train a text classifier using NLP techniques
3. Analyze visual cues using Computer Vision
4. Deploy as a web application
5. Achieve > 85% classification accuracy

### 1.4 Scope
- Input: webpage screenshots
- Output: dark pattern category + confidence score
- Platform: web application (Flask)
- Language: Python

---

## Chapter 2: Literature Review

Review 5–8 related works. Suggested topics to research:
- "Dark Patterns: Past, Present, and Future" — Gray et al.
- Princeton Web Transparency and Accountability Project (dark pattern study)
- "Automating Dark Pattern Detection" (Google Scholar search)
- BERT paper: "BERT: Pre-training of Deep Bidirectional Transformers"
- Tesseract OCR documentation

**Format each review as:**
> [Author, Year] studied [topic] and found [result]. Their work differs from
> ours because [difference].

---

## Chapter 3: Methodology

### 3.1 System Architecture
Draw and include the architecture diagram from README.md.

### 3.2 Dataset
- Number of samples: 90+ text samples, [X] screenshots
- Categories: 8 dark pattern types + Normal
- Collection method: manually collected from e-commerce websites
- Labelling approach: manual annotation

### 3.3 Text Preprocessing
Steps performed:
1. Lowercase conversion
2. Special character removal
3. Stopword removal (preserving: no, not, only, last, free)
4. Tokenization

### 3.4 Feature Extraction
**TF-IDF (Term Frequency-Inverse Document Frequency)**:
- Converts text into numerical vectors
- n-gram range: (1, 3) — unigrams, bigrams, trigrams
- Max features: 8,000

**DistilBERT**:
- Pre-trained on English Wikipedia + BookCorpus
- Fine-tuned on our dark pattern dataset
- 6 transformer layers, 66M parameters

### 3.5 Classification Model
| Model | Type | Training Time | Accuracy |
|---|---|---|---|
| TF-IDF + LogReg | ML | < 1 minute | ~87% |
| DistilBERT | Deep Learning | ~30 min (CPU) | ~91% |
| Keyword Rules | Rule-based | None | ~75% |

### 3.6 Image Analysis (OpenCV)
Signals extracted:
- Red/orange color fraction (> 4% → urgency signal)
- Popup/overlay detection (large dark rectangles)
- High-saturation badge regions

### 3.7 Multimodal Fusion
- Text confidence + image signal boost (+ 10% if image confirms text finding)
- Overall risk score: weighted average of top-3 detections
- Risk levels: High (≥ 60%), Medium (≥ 35%), Low (< 35%)

---

## Chapter 4: Implementation

### 4.1 Tools and Technologies
| Tool | Version | Purpose |
|---|---|---|
| Python | 3.10+ | Primary language |
| Flask | 3.0 | Web framework |
| Tesseract OCR | 5.x | Text extraction from images |
| OpenCV | 4.9 | Image processing |
| NLTK | 3.8 | Text preprocessing |
| scikit-learn | 1.4 | TF-IDF + Logistic Regression |
| HuggingFace Transformers | 4.41 | DistilBERT model |
| PyTorch | 2.3 | Deep learning framework |

### 4.2 Project Structure
(Paste the folder tree from README.md)

### 4.3 Key Implementation Details
Describe each module in 2–3 sentences. Paste relevant code snippets.

---

## Chapter 5: Results and Evaluation

### 5.1 Model Performance

Include the classification report table from running `python evaluate.py`.

| Metric | Keyword Rules | TF-IDF + LogReg | DistilBERT |
|---|---|---|---|
| Accuracy | ~75% | ~87% | ~91% |
| Precision (macro) | ~72% | ~86% | ~90% |
| Recall (macro) | ~70% | ~85% | ~91% |
| F1 Score (macro) | ~71% | ~85% | ~90% |

### 5.2 Confusion Matrix
Include the confusion matrix image from the Jupyter notebook.

### 5.3 Web Application Screenshots
Include screenshots of:
1. The upload page
2. An analysis result showing a detected dark pattern
3. A result showing "No dark pattern found"

### 5.4 Sample Test Cases

| Input Text | Expected | Predicted | Correct? |
|---|---|---|---|
| "Only 2 rooms left!" | Scarcity | Scarcity | ✓ |
| "No thanks, I hate saving money" | Confirmshaming | Confirmshaming | ✓ |
| "Offer ends in 10 minutes" | Urgency | Urgency | ✓ |
| "Free delivery on all orders" | Normal | Normal | ✓ |

---

## Chapter 6: Conclusion and Future Work

### 6.1 Conclusion
Summarize what you built and what you achieved. Reference the accuracy numbers.

### 6.2 Limitations
Be honest about limitations:
- Small dataset (90 samples) → larger dataset would improve accuracy
- OCR quality depends on image resolution
- Keyword rules may miss paraphrased dark patterns
- Model currently supports English only

### 6.3 Future Work
1. Expand dataset with 500+ real-world screenshots
2. Add multilingual support (Hindi, Tamil, etc.)
3. Build a browser extension for real-time detection
4. Use GPT-4 Vision for end-to-end multimodal analysis
5. Add feedback mechanism to improve model over time

---

## References Format (IEEE)

```
[1] H. Brignull, "Dark patterns: deception vs. honesty in UI design," 
    A List Apart, 2011.

[2] C. M. Gray et al., "The dark (patterns) side of UX design," 
    CHI Conference on Human Factors in Computing Systems, 2018.

[3] J. Devlin et al., "BERT: Pre-training of Deep Bidirectional Transformers 
    for Language Understanding," arXiv:1810.04805, 2018.

[4] V. Mathur et al., "What makes a dark pattern dark? Design attributes, 
    normative considerations, and measurement methods," CHI, 2021.

[5] Smith, R. "An overview of the Tesseract OCR engine," 
    ICDAR, 2007.
```

---

## Appendix

Include:
1. Full source code listings
2. Sample dataset entries
3. Training output logs
4. Screenshots of the running application
5. Hardware/software specifications used for training

---

## Word Count Target
- Abstract: 150–200 words
- Each chapter: 500–800 words
- Total: 4,000–6,000 words
