# Complete Beginner's Guide — Pattern Audit

This guide explains every file, every concept, and every step of the project
in beginner-friendly language.

---

## What is a Dark Pattern?

A **dark pattern** is a trick built into a website's design that manipulates
you into doing something you didn't intend to do — like buying something,
subscribing to a service, or sharing personal data.

### Real Examples

| Dark Pattern | What it looks like | Why it's deceptive |
|---|---|---|
| Scarcity | "Only 2 seats left!" | May be fake — creates pressure |
| Urgency | "Offer ends in 10 min!" | Fake countdown — resets every visit |
| Confirmshaming | "No thanks, I hate saving money" | Guilt-trips you into clicking Yes |
| Hidden Costs | "$49/night*" (*+$25 fees) | Real price hidden until checkout |
| Forced Action | "Create account to continue" | Forces signup just to browse |
| Pre-selected Options | Travel insurance pre-ticked | You pay extra without noticing |

---

## Project Architecture (How it All Fits Together)

```
User uploads screenshot
        │
        ▼
   OCR (Tesseract)          ← Reads text from the image
        │
        ▼
  Text Classifier           ← Finds dark pattern words/phrases
  (Keyword Rules)
        │
        ├─── Image Analyzer ← Detects red colors, popups, badges (OpenCV)
        │
        ▼
   Fusion Layer             ← Combines text + image results
        │
        ▼
   Flask Web App            ← Shows results in the browser
```

---

## File-by-File Explanation

### `app.py` — The Web Server
**What it does**: This is the main program. It runs a web server using Flask.

```
When you open http://localhost:5000:
  → Flask serves the index.html page

When you click "Analyze":
  → Flask receives your image + text
  → Calls OCR to extract text from the image
  → Calls the text classifier
  → Calls the image analyzer
  → Returns the result as JSON
  → The browser shows the result
```

**Key concepts for beginners**:
- `@app.route("/")` — This is called a "route". It tells Flask: "when someone visits /, run this function."
- `request.files.get("screenshot")` — Gets the uploaded file from the form.
- `jsonify(result)` — Converts a Python dictionary to JSON so the browser can read it.

---

### `models/text_classifier.py` — Finds Dark Pattern Text

**What it does**: Scans text for dark pattern phrases using two methods:

**Method 1: Keyword Rules**
```python
# Example rule for Scarcity:
r"\bonly\s+\d+\s+(items?|rooms?|seats?)\b"

# This regex matches:
# "Only 2 items left"  ✓
# "Only 3 rooms available"  ✓
# "Only 1 seat remaining"  ✓
```

**How regex works** (beginner explanation):
- `\b` = word boundary (start/end of a word)
- `\d+` = one or more digits (1, 2, 15, etc.)
- `\s+` = one or more spaces
- `(items?|rooms?)` = the word "item", "items", "room", or "rooms"

**Method 2: DistilBERT (ML Model)**
A pre-trained language model fine-tuned on our dark pattern dataset.
It understands context, not just keywords.

---

### `models/image_analyzer.py` — Reads the Screenshot Visually

**What it does**: Uses OpenCV to analyze the visual appearance of the screenshot.

**Techniques used**:

1. **Color Analysis** — Urgency websites use red/orange colors
   ```python
   # Convert image to HSV color space
   hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
   # Detect red pixels
   red_mask = cv2.inRange(hsv, RED_LOWER, RED_UPPER)
   ```

2. **Popup Detection** — Finds large dark overlay rectangles
   ```python
   edges = cv2.Canny(gray, 50, 150)
   contours = cv2.findContours(edges, ...)
   ```

3. **Badge Detection** — Finds small colorful badge-like elements (SALE, %)

---

### `utils/ocr.py` — Extracts Text from Screenshots

**What it does**: Uses Tesseract (a free OCR engine) to read text from images.

```python
import pytesseract
text = pytesseract.image_to_string(image)
# Input:  Screenshot with "Only 2 rooms left!"
# Output: "Only 2 rooms left!" (as a string)
```

**Why OCR is needed**: The AI cannot directly "read" an image. OCR converts
the image to text first, then the text classifier can analyze it.

---

### `models/fusion.py` — Combines Everything

**What it does**: Takes results from the text classifier AND image analyzer,
and merges them into one final answer.

```
Text says "Urgency" (confidence 65%)
+
Image shows red/orange color dominance
= Urgency (confidence boosted to 75%)
```

If both text and image agree on a pattern, the confidence goes up.

---

### `static/css/style.css` — Visual Design

Styles the webpage. Uses CSS variables for a dark theme:
```css
:root {
  --bg:     #0f1117;   /* dark background */
  --accent: #6c63ff;   /* purple highlight */
  --danger: #ef4444;   /* red for high risk */
}
```

---

### `static/js/main.js` — Browser Interactivity

**What it does**: Handles user interactions without reloading the page.

```javascript
// When user clicks "Analyze":
form.addEventListener("submit", async (e) => {
    e.preventDefault();                     // stop page reload
    const data = await fetch("/analyze");   // call Flask API
    renderResults(data);                    // show results
});
```

---

### `dataset/sample_data.py` — Training Data

Contains 90+ labelled text examples used to train the ML model.

```python
{"text": "Only 2 rooms left!", "label": "Scarcity"},
{"text": "Act now! Time is running out.", "label": "Urgency"},
{"text": "No thanks, I hate saving money.", "label": "Confirmshaming"},
```

---

### `dataset/train_classifier.py` — Training Script

Trains the machine learning model on the sample data.

**Step 1 — TF-IDF** (fast, no GPU needed):
```
Text → TF-IDF → Feature Vector → Logistic Regression → Label
```

**Step 2 — DistilBERT** (more accurate, slower):
```
Text → Tokenizer → DistilBERT → Classifier Head → Label
```

---

### `evaluate.py` — Testing the Model

Measures how well the model performs:
- **Accuracy**: Out of 100 texts, how many were correctly classified?
- **Precision**: When the model says "Scarcity", how often is it right?
- **Recall**: Out of all actual Scarcity texts, how many did the model find?
- **F1 Score**: Balance of precision and recall (main metric to report)

---

## Step-by-Step: Running the Project

### Step 1: Install Requirements
```bash
pip install -r requirements.txt
```

### Step 2: Install Tesseract OCR
Download from: https://github.com/UB-Mannheim/tesseract/wiki
Install to default path: `C:\Program Files\Tesseract-OCR\`

### Step 3: Train the Model
```bash
python dataset/train_classifier.py --model tfidf
```
Expected output:
```
5-Fold CV Accuracy: 88.5% ± 3.2%
Model saved → models/tfidf_model.pkl
```

### Step 4: Evaluate the Model
```bash
python evaluate.py
```

### Step 5: Run the Web App
```bash
python app.py
```
Open http://localhost:5000

### Step 6: Test the System
1. Go to http://localhost:5000
2. Upload a screenshot from a booking or e-commerce site
3. Click "Analyze"
4. See the detected dark pattern category and confidence score

---

## Expected Outputs

### Terminal after training:
```
5-Fold CV Accuracy : 87.50% ± 4.50%

── Classification Report ──
                     precision  recall  f1-score  support
Scarcity               0.90      0.90     0.90       10
Urgency                0.89      0.89     0.89       10
Confirmshaming         0.88      0.88     0.88       10
Hidden Costs           0.85      0.85     0.85       10
Forced Action          0.87      0.87     0.87       10
Pre-selected Options   0.86      0.86     0.86       10
Normal                 0.92      0.92     0.92       10

accuracy                          0.88       80
```

### Web app result:
```
🚨 HIGH RISK — Dark Patterns Detected

Primary: Scarcity (75% confidence)
  "Only 2 rooms left at this price!"

Secondary: Urgency (65% confidence)
  "Offer expires in 10 minutes"
```

---

## What to Show in Your College Demo

1. Open the web app in browser
2. Upload a screenshot from Amazon or Booking.com
3. Show the detected patterns in real-time
4. Open the terminal and show the evaluation metrics
5. Show the Jupyter notebook with charts

---

## Common Errors and Fixes

| Error | Cause | Fix |
|---|---|---|
| `TesseractNotFoundError` | Tesseract not installed | Install from UB-Mannheim link above |
| `ModuleNotFoundError: flask` | Flask not installed | `pip install flask` |
| `ModuleNotFoundError: cv2` | OpenCV not installed | `pip install opencv-python` |
| Port 5000 already in use | Another app using port | Change port in app.py: `app.run(port=5001)` |
| Model not found | Not trained yet | Run `python dataset/train_classifier.py` |
