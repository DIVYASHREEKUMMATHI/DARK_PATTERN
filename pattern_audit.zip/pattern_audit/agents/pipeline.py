"""
Four-agent detection pipeline orchestrator.

Flow (mirrors the project's sequence/activity diagrams):

    Visual Perception Agent  ─┐
                               ├──▶  Cross-Modal Reasoning Agent  ──▶  Verdict & Report Agent
    Text Extraction Agent    ─┘

The first two agents run independently (conceptually "in parallel" — no
agent depends on another's output at this stage). Their results are then
fused by the Cross-Modal Reasoning Agent, and finally classified into a
human-readable verdict by the Verdict & Report Agent.
"""

from agents import (
    visual_perception_agent,
    text_extraction_agent,
    cross_modal_reasoning_agent,
    verdict_report_agent,
)


def run_pipeline(
    image_input=None,
    raw_text: str = "",
    use_ocr: bool = True,
    use_transformer: bool = False,
    use_saved_model: bool = True,
) -> dict:
    """
    Runs the full four-agent pipeline and returns a result shaped for the
    Flask API — includes both the final merged fields (for backward
    compatibility with the existing frontend) AND a per-agent breakdown
    under "agents" for the new individual risk-percentage display.
    """

    # ── Agent 1 + 2 (independent) ──────────────────────────────────────────
    text_out = text_extraction_agent.run(
        image_input=image_input,
        raw_text=raw_text,
        use_ocr=use_ocr,
        use_transformer=use_transformer,
        use_saved_model=use_saved_model,
    )

    visual_out = visual_perception_agent.run(image_input, annotate=True)

    # ── Agent 3 (fusion) ────────────────────────────────────────────────────
    cross_modal_out = cross_modal_reasoning_agent.run(visual_out, text_out)

    # ── Agent 4 (final verdict) ─────────────────────────────────────────────
    verdict_out = verdict_report_agent.run(cross_modal_out)

    agents_breakdown = [
        {
            "agent":           visual_perception_agent.AGENT_NAME,
            "ran":              visual_out.get("ran", False),
            "risk_percentage":  visual_out.get("risk_percentage", 0),
            "findings":         visual_out.get("findings", []),
        },
        {
            "agent":           text_extraction_agent.AGENT_NAME,
            "ran":              text_out.get("ran", False),
            "risk_percentage":  text_out.get("risk_percentage", 0),
            "findings":         text_out.get("findings", []),
        },
        {
            "agent":           cross_modal_reasoning_agent.AGENT_NAME,
            "ran":              True,
            "risk_percentage":  cross_modal_out.get("risk_percentage", 0),
            "findings":         cross_modal_out.get("cross_modal_notes", []),
        },
        {
            "agent":           verdict_report_agent.AGENT_NAME,
            "ran":              True,
            "risk_percentage":  verdict_out.get("risk_percentage", 0),
            "findings":         [verdict_out.get("summary", "")],
        },
    ]

    return {
        # Final verdict fields (top-level, used by the results banner)
        "dark_pattern_found":   bool(verdict_out["detections"]),
        "verdict":              verdict_out["verdict"],
        "overall_risk":         verdict_out["overall_risk"],
        "risk_score":           verdict_out["risk_score"],
        "detections":           verdict_out["detections"],
        "summary":              verdict_out["summary"],

        # Per-agent breakdown (new — individual risk %, in pipeline order)
        "agents":               agents_breakdown,

        # Supporting/raw data
        "ocr_text":             text_out.get("ocr_text", ""),
        "annotated_image_b64":  visual_out.get("annotated_image_b64"),
        "text_method":          text_out.get("method", "keyword"),
        "visual_patterns":      visual_out.get("findings", []),
    }
