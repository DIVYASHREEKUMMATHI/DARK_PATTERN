"""
Agent 3 — Cross-Modal Reasoning Agent
=======================================
Takes the independent outputs of the Visual Perception Agent and the Text
Extraction Agent and reasons about them together. This is where dark
patterns that only emerge from the COMBINATION of visual + text evidence
get identified (e.g. a prominent "Accept" button + deliberately vague
"decline" text).

Key design decision — corroboration-based trust:
--------------------------------------------------
Visual-only signals (a red logo, a promotional-looking badge) are
inherently ambiguous on their own and are a common source of false
positives on completely legitimate pages. This agent only lets visual
evidence contribute at FULL weight when the Text Extraction Agent found
a matching category. Uncorroborated visual evidence is down-weighted
substantially (see UNCORROBORATED_VISUAL_WEIGHT) rather than discarded,
since a real dark pattern *can* be visual-only (e.g. a disguised ad with
no manipulative text) — it just shouldn't dominate the verdict alone.
"""

AGENT_NAME = "Cross-Modal Reasoning Agent"

# How much of the Visual Perception Agent's confidence survives when
# nothing in the text corroborates it. 1.0 = full trust, 0.0 = ignore.
UNCORROBORATED_VISUAL_WEIGHT = 0.35

# When visual signal categories DO overlap with a text detection, boost
# that detection's confidence by this much (evidence agreeing across
# modalities is stronger evidence).
CORROBORATION_BOOST = 0.12


def _severity_label(confidence: float) -> str:
    if confidence >= 0.80:
        return "High"
    if confidence >= 0.55:
        return "Medium"
    return "Low"


def _visual_categories(visual_signals: dict) -> set:
    """Map raw visual signals to the text-classifier's category names."""
    cats = set()
    if visual_signals.get("high_urgency_color"):
        cats.update({"Urgency", "Scarcity"})
    if visual_signals.get("popup_detected"):
        cats.update({"Forced Action", "Forced Continuity", "Roach Motel"})
    badges = visual_signals.get("badge_regions", [])
    if isinstance(badges, list) and len(badges) >= 3:
        cats.update({"Scarcity", "Hidden Costs", "Pre-selected Options"})
    return cats


def run(visual_result: dict, text_result: dict) -> dict:
    """
    Fuse the Visual Perception Agent output and Text Extraction Agent output.

    Args:
        visual_result : dict returned by agents.visual_perception_agent.run()
        text_result   : dict returned by agents.text_extraction_agent.run()

    Returns:
      {
        "agent": "Cross-Modal Reasoning Agent",
        "risk_percentage": int,       # 0-100, THIS agent's fused score
        "detections": [...],          # fused, ranked detections
        "cross_modal_notes": [str],   # explanation of any corroboration/downweighting applied
      }
    """
    visual_signals = visual_result.get("signals", {}) or {}
    visual_cats    = _visual_categories(visual_signals)
    text_detected  = bool(text_result.get("detections"))

    notes = []
    detections = []
    seen = set()

    # ── Start from text detections, boost when visually corroborated ──────────
    for det in text_result.get("detections", []):
        cat  = det["category"]
        conf = det["confidence"]

        if cat in visual_cats:
            boost = CORROBORATION_BOOST
            conf  = min(conf + boost, 0.97)
            source = "text+visual (corroborated)"
            notes.append(f"'{cat}' confirmed by both text and visual cues — confidence boosted.")
        else:
            source = "text"

        detections.append({
            "category":         cat,
            "confidence":       round(conf, 2),
            "severity":         _severity_label(conf),
            "source":           source,
            "matched_snippets": det.get("matched_snippets", []),
            "description":      det.get("description", ""),
            "example":          det.get("example", ""),
            "suggested_fix":    det.get("suggested_fix", ""),
        })
        seen.add(cat)

    # ── Add visual-only findings, down-weighted unless corroborated ──────────
    if visual_result.get("ran") and visual_result.get("findings"):
        img_conf = visual_result.get("risk_percentage", 0) / 100.0

        for finding in visual_result["findings"]:
            if "urgency" in finding.lower() or "scarcity" in finding.lower():
                cat = "Urgency/Scarcity (Visual)"
            elif "popup" in finding.lower() or "overlay" in finding.lower():
                cat = "Forced Attention (Visual)"
            elif "badge" in finding.lower():
                cat = "Promotional Pressure (Visual)"
            else:
                cat = "Visual Dark Pattern"

            if cat in seen:
                continue

            if not text_detected:
                weighted_conf = img_conf * UNCORROBORATED_VISUAL_WEIGHT
                notes.append(
                    f"'{cat}' is visual-only with no text corroboration — "
                    f"confidence reduced from {img_conf*100:.0f}% to {weighted_conf*100:.0f}% "
                    f"to avoid over-flagging based on color/layout alone."
                )
            else:
                weighted_conf = img_conf
                notes.append(f"'{cat}' visual finding kept at full weight — text evidence also present elsewhere.")

            if weighted_conf < 0.05:
                continue  # negligible, don't clutter the report

            detections.append({
                "category":         cat,
                "confidence":       round(weighted_conf, 2),
                "severity":         _severity_label(weighted_conf),
                "source":           "visual-only" if not text_detected else "visual",
                "matched_snippets": [],
                "description":      finding,
                "example":          "",
            })
            seen.add(cat)

    detections.sort(key=lambda x: x["confidence"], reverse=True)

    # ── This agent's own overall risk (weighted top-3, same scheme as before) ─
    top_confs = [d["confidence"] for d in detections[:3]]
    if top_confs:
        weights = [0.50, 0.30, 0.20]
        risk_score = sum(w * c for w, c in zip(weights, top_confs + [0, 0, 0]))
    else:
        risk_score = 0.0
    risk_score = round(min(risk_score, 1.0), 2)

    if not notes:
        notes.append("No cross-modal corroboration signals were relevant for this input.")

    return {
        "agent":             AGENT_NAME,
        "risk_percentage":   round(risk_score * 100),
        "detections":        detections,
        "cross_modal_notes": notes,
    }
