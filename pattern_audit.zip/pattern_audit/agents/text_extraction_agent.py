"""
Agent 2 — Text Extraction Agent
=================================
Extracts on-screen text (via OCR, if only an image was supplied) and runs
it through the NLP/keyword classifier to identify manipulative language
patterns: false urgency, scarcity claims, confirmshaming, hidden costs, etc.

Runs independently of the Visual Perception Agent (parallel in the pipeline).
"""

from models.text_classifier import classify_text

AGENT_NAME = "Text Extraction Agent"


def run(image_input=None, raw_text: str = "", use_ocr: bool = True,
        use_transformer: bool = False, use_saved_model: bool = True) -> dict:
    """
    Main entry point for the Text Extraction Agent.

    Args:
        image_input      : image to OCR if raw_text is empty (optional)
        raw_text         : pre-supplied text (skips OCR when non-empty)
        use_ocr          : whether to run Tesseract OCR when needed
        use_transformer  : whether to run the optional BART zero-shot model
        use_saved_model  : whether to use the trained TF-IDF model if present

    Returns:
      {
        "agent": "Text Extraction Agent",
        "ran": bool,
        "risk_percentage": int,        # 0-100, THIS agent's own score
        "findings": [str],             # human-readable findings
        "detections": [...],           # raw per-category detections
        "ocr_text": str,
        "method": str,                 # which classifier backend was used
      }
    """
    ocr_text = raw_text

    if use_ocr and image_input is not None and not raw_text.strip():
        try:
            from utils.ocr import extract_text
            ocr_text = extract_text(image_input)
        except Exception as exc:
            ocr_text = ""
            print(f"[Text Extraction Agent] OCR warning: {exc}")

    if not ocr_text.strip():
        return {
            "agent": AGENT_NAME,
            "ran": False,
            "risk_percentage": 0,
            "findings": [],
            "detections": [],
            "ocr_text": "",
            "method": "none",
        }

    result = classify_text(
        ocr_text,
        use_transformer=use_transformer,
        use_saved_model=use_saved_model,
    )
    detections = result.get("detections", [])

    findings = [
        f"{d['category']} language detected ({d['confidence']*100:.0f}% confidence): "
        f"\"{d['matched_snippets'][0]}\"" if d.get("matched_snippets") else
        f"{d['category']} language detected ({d['confidence']*100:.0f}% confidence)"
        for d in detections
    ]

    top_conf = max((d["confidence"] for d in detections), default=0.0)

    return {
        "agent":           AGENT_NAME,
        "ran":             True,
        "risk_percentage": round(top_conf * 100),
        "findings":        findings,
        "detections":      detections,
        "ocr_text":        ocr_text,
        "method":          result.get("method", "keyword"),
    }
