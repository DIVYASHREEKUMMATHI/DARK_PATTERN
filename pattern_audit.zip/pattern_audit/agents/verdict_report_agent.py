"""
Agent 4 — Verdict & Report Agent
===================================
Takes the fused output of the Cross-Modal Reasoning Agent and produces the
final, human-readable classification and explanation. This is the only
agent whose output is meant to be read directly by an end user.

Final verdict categories (matching the project's use-case documentation):
  - "Likely Safe"           — no meaningful risk detected
  - "Dark Pattern Detected" — manipulative UI/copy patterns found
  - "Scam Detected"         — very high-confidence, multi-category, high-severity
                              combination that goes beyond a single dark pattern
                              (e.g. forced continuity + hidden costs + high
                              overall confidence together)
"""

AGENT_NAME = "Verdict & Report Agent"

SCAM_RISK_THRESHOLD       = 0.85   # overall risk_score at/above this...
SCAM_MIN_HIGH_SEVERITY    = 2      # ...AND at least this many High-severity detections...
SCAM_MIN_CATEGORIES       = 3      # ...AND at least this many distinct categories = "Scam Detected"


def run(cross_modal_result: dict) -> dict:
    """
    Args:
        cross_modal_result : dict returned by agents.cross_modal_reasoning_agent.run()

    Returns:
      {
        "agent": "Verdict & Report Agent",
        "verdict": "Likely Safe" | "Dark Pattern Detected" | "Scam Detected",
        "overall_risk": "None" | "Low" | "Medium" | "High",
        "risk_score": float,        # 0.0-1.0
        "risk_percentage": int,     # 0-100 (same score, agent-report format)
        "summary": str,
        "detections": [...],        # pass-through, ranked
      }
    """
    detections = cross_modal_result.get("detections", [])
    risk_score = cross_modal_result.get("risk_percentage", 0) / 100.0

    if risk_score >= 0.60:
        overall_risk = "High"
    elif risk_score >= 0.35:
        overall_risk = "Medium"
    elif risk_score > 0.0:
        overall_risk = "Low"
    else:
        overall_risk = "None"

    high_severity_count = sum(1 for d in detections if d.get("severity") == "High")
    distinct_categories = len({d["category"] for d in detections})

    if (risk_score >= SCAM_RISK_THRESHOLD
            and high_severity_count >= SCAM_MIN_HIGH_SEVERITY
            and distinct_categories >= SCAM_MIN_CATEGORIES):
        verdict = "Scam Detected"
    elif detections:
        verdict = "Dark Pattern Detected"
    else:
        verdict = "Likely Safe"

    if detections:
        top  = detections[0]
        cats = ", ".join(d["category"] for d in detections[:3])
        summary = (
            f"{verdict} ({overall_risk} risk). "
            f"Primary concern: {top['category']} ({top['confidence']*100:.0f}% confidence). "
            f"Categories found: {cats}."
        )
    else:
        summary = "Likely Safe — no manipulative UI or copy patterns were detected in this input."

    return {
        "agent":           AGENT_NAME,
        "verdict":         verdict,
        "overall_risk":    overall_risk,
        "risk_score":      round(risk_score, 2),
        "risk_percentage": round(risk_score * 100),
        "summary":         summary,
        "detections":      detections,
    }
