"""
Agent 1 — Visual Perception Agent
==================================
Analyzes a webpage screenshot using computer vision (OpenCV) to detect
UI-level manipulation cues: dominant urgency colors, popup/modal overlays,
and promotional badge clusters.

Design note on false positives
-------------------------------
Earlier versions of this heuristic flagged ANY page with red/orange brand
colors (logos, buttons, product photos) as "urgency," which produced false
positives on completely trustworthy pages. This version:
  - Raises the color-dominance threshold substantially (was 4%, now 18%)
  - Requires a stronger, larger dark-overlay signal before calling something
    a "popup" (reduces false hits on hero images / photography with shadow)
  - Requires 3+ badge-like regions (was 2) before flagging promotional badges
  - Caps this agent's own risk contribution at 45% when it has NO
    corroborating text evidence — visual-only signals are inherently
    ambiguous and should never alone justify a "High risk" verdict.
    (The Cross-Modal Reasoning Agent decides whether to trust it more.)
"""

import cv2
import numpy as np
from PIL import Image
import base64

AGENT_NAME = "Visual Perception Agent"

# ── Colour masks (HSV ranges) ─────────────────────────────────────────────────
RED_LOWER1  = np.array([0,   120, 70],  dtype=np.uint8)
RED_UPPER1  = np.array([10,  255, 255], dtype=np.uint8)
RED_LOWER2  = np.array([170, 120, 70],  dtype=np.uint8)
RED_UPPER2  = np.array([180, 255, 255], dtype=np.uint8)
ORANGE_LOWER = np.array([11,  120, 70],  dtype=np.uint8)
ORANGE_UPPER = np.array([25,  255, 255], dtype=np.uint8)
YELLOW_LOWER = np.array([26, 100, 100], dtype=np.uint8)
YELLOW_UPPER = np.array([35, 255, 255], dtype=np.uint8)

# Tuned thresholds (raised to cut false positives on normal/trusted pages)
COLOR_THRESHOLD    = 0.18   # was 0.04 — a page needs SUBSTANTIAL red/orange coverage
MIN_BADGE_COUNT    = 3      # was 2
POPUP_DARK_DELTA   = 35     # was 20 — popup overlay must be markedly darker
NO_TEXT_RISK_CAP   = 0.45   # visual-only confidence ceiling without text corroboration


def _to_cv2(image_input) -> np.ndarray:
    if isinstance(image_input, np.ndarray):
        return image_input
    if isinstance(image_input, Image.Image):
        return cv2.cvtColor(np.array(image_input.convert("RGB")), cv2.COLOR_RGB2BGR)
    if isinstance(image_input, (bytes, bytearray)):
        arr = np.frombuffer(image_input, dtype=np.uint8)
        return cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if isinstance(image_input, str):
        return cv2.imread(image_input)
    raise TypeError(f"Unsupported image type: {type(image_input)}")


def _dominant_color_analysis(img_bgr: np.ndarray) -> dict:
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    total = hsv.shape[0] * hsv.shape[1]
    red   = cv2.bitwise_or(cv2.inRange(hsv, RED_LOWER1, RED_UPPER1),
                            cv2.inRange(hsv, RED_LOWER2, RED_UPPER2))
    orange = cv2.inRange(hsv, ORANGE_LOWER, ORANGE_UPPER)
    yellow = cv2.inRange(hsv, YELLOW_LOWER, YELLOW_UPPER)
    return {
        "red_fraction":    float(np.count_nonzero(red))    / total,
        "orange_fraction": float(np.count_nonzero(orange)) / total,
        "yellow_fraction": float(np.count_nonzero(yellow)) / total,
    }


def _detect_popup_overlay(img_bgr: np.ndarray) -> bool:
    gray  = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    h, w  = gray.shape
    edges = cv2.Canny(gray, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    img_area = h * w
    for cnt in contours:
        x, y, cw, ch = cv2.boundingRect(cnt)
        area_ratio = (cw * ch) / img_area
        aspect = cw / max(ch, 1)
        if 0.15 < area_ratio < 0.65 and 0.4 < aspect < 3.0:
            inner  = gray[y + 10: y + ch - 10, x + 10: x + cw - 10]
            border = gray[max(0, y - 5): y + 5, x: x + cw]
            if inner.size > 0 and border.size > 0:
                if np.mean(inner) < np.mean(border) - POPUP_DARK_DELTA:
                    return True
    return False


def _detect_badge_regions(img_bgr: np.ndarray) -> list:
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    sat_mask = cv2.inRange(hsv, np.array([0, 150, 100]), np.array([180, 255, 255]))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    sat_mask = cv2.morphologyEx(sat_mask, cv2.MORPH_CLOSE, kernel)
    contours, _ = cv2.findContours(sat_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    h, w = img_bgr.shape[:2]
    badges = []
    for cnt in contours:
        x, y, cw, ch = cv2.boundingRect(cnt)
        area_ratio = (cw * ch) / (h * w)
        aspect = cw / max(ch, 1)
        if 0.001 < area_ratio < 0.08 and 0.4 < aspect < 2.5:
            badges.append({"x": x, "y": y, "w": cw, "h": ch})
    return badges


def _annotate_image(img_bgr: np.ndarray, signals: dict) -> str:
    annotated = img_bgr.copy()
    for badge in signals.get("badge_regions", []):
        x, y, bw, bh = badge["x"], badge["y"], badge["w"], badge["h"]
        cv2.rectangle(annotated, (x, y), (x + bw, y + bh), (0, 0, 255), 2)
        cv2.putText(annotated, "Badge", (x, max(y - 5, 0)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
    if signals.get("popup_detected"):
        h, w = annotated.shape[:2]
        cv2.putText(annotated, "POPUP OVERLAY DETECTED",
                    (10, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    _, buf = cv2.imencode(".png", annotated)
    return base64.b64encode(buf).decode("utf-8")


def run(image_input, annotate: bool = True) -> dict:
    """
    Main entry point for the Visual Perception Agent.
    Runs independently of the Text Extraction Agent (parallel in the pipeline) —
    it has no knowledge of any text findings. Cross-modal weighting/capping of
    visual-only evidence happens downstream in the Cross-Modal Reasoning Agent.

    Args:
        image_input : file path / bytes / PIL Image / ndarray, or None
        annotate     : whether to draw bounding boxes on findings

    Returns:
      {
        "agent": "Visual Perception Agent",
        "ran": bool,                       # False if no image was supplied
        "risk_percentage": int,            # 0-100, THIS agent's own score
        "findings": [str],                 # human-readable visual findings
        "signals": {...},                  # raw detector signals (for fusion)
        "annotated_image_b64": str | None,
      }
    """
    if image_input is None:
        return {
            "agent": AGENT_NAME,
            "ran": False,
            "risk_percentage": 0,
            "findings": [],
            "signals": {},
            "annotated_image_b64": None,
        }

    img = _to_cv2(image_input)
    if img is None:
        return {
            "agent": AGENT_NAME,
            "ran": False,
            "risk_percentage": 0,
            "findings": [],
            "signals": {},
            "annotated_image_b64": None,
            "error": "Could not decode image",
        }

    max_dim = 800
    h, w = img.shape[:2]
    if max(h, w) > max_dim:
        scale = max_dim / max(h, w)
        img = cv2.resize(img, (int(w * scale), int(h * scale)))

    color_data = _dominant_color_analysis(img)
    popup      = _detect_popup_overlay(img)
    badges     = _detect_badge_regions(img)

    urgency_color = (
        color_data["red_fraction"]    > COLOR_THRESHOLD or
        color_data["orange_fraction"] > COLOR_THRESHOLD
    )
    many_badges = len(badges) >= MIN_BADGE_COUNT

    signals = {
        "high_urgency_color": urgency_color,
        "popup_detected":     popup,
        "badge_regions":      badges,
        "color_fractions":    color_data,
    }

    findings = []
    confidence_sum = 0.0

    if urgency_color:
        findings.append(
            f"Dominant red/orange coloring covers "
            f"{max(color_data['red_fraction'], color_data['orange_fraction'])*100:.0f}% "
            f"of the screenshot — consistent with urgency/scarcity styling."
        )
        confidence_sum += 0.45

    if popup:
        findings.append("A large, markedly darker rectangular overlay was detected — consistent with a popup/modal.")
        confidence_sum += 0.50

    if many_badges:
        findings.append(f"{len(badges)} high-saturation badge-like regions detected — consistent with promotional badge clustering.")
        confidence_sum += 0.40

    raw_confidence = min(confidence_sum, 0.90) if findings else 0.0

    annotated_b64 = None
    if annotate and findings:
        annotated_b64 = _annotate_image(img, signals)

    return {
        "agent":                AGENT_NAME,
        "ran":                  True,
        "risk_percentage":      round(raw_confidence * 100),
        "findings":             findings,
        "signals":              signals,
        "annotated_image_b64":  annotated_b64,
    }
