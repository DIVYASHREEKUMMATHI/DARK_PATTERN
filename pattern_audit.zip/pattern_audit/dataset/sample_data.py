"""
Labelled dataset for training and evaluation.
Labels: Scarcity | Urgency | Confirmshaming | Hidden Costs |
        Forced Action | Pre-selected Options | Forced Continuity | Roach Motel | Normal
"""

SAMPLES = [

    # ── Scarcity ──────────────────────────────────────────────────────────────
    {"text": "Only 2 rooms left at this price!", "label": "Scarcity"},
    {"text": "Only 3 items left in stock. Order soon!", "label": "Scarcity"},
    {"text": "Hurry! Limited seats available.", "label": "Scarcity"},
    {"text": "Almost gone! Only 1 unit remaining.", "label": "Scarcity"},
    {"text": "5 other people are viewing this right now.", "label": "Scarcity"},
    {"text": "This deal is selling fast — grab yours before it's gone.", "label": "Scarcity"},
    {"text": "Limited stock. We can't guarantee availability.", "label": "Scarcity"},
    {"text": "Last chance! Only a few items left.", "label": "Scarcity"},
    {"text": "Low stock — only 4 remaining.", "label": "Scarcity"},
    {"text": "12 people are looking at this hotel right now.", "label": "Scarcity"},

    # ── Urgency ──────────────────────────────────────────────────────────────
    {"text": "Offer expires in 10:00 minutes!", "label": "Urgency"},
    {"text": "Sale ends tonight at midnight.", "label": "Urgency"},
    {"text": "Today only — 50% off all items.", "label": "Urgency"},
    {"text": "Flash sale: 2 hours left!", "label": "Urgency"},
    {"text": "Don't miss out — deal ends soon.", "label": "Urgency"},
    {"text": "Act now! Time is running out.", "label": "Urgency"},
    {"text": "Hurry! Offer expires at 11:59 PM tonight.", "label": "Urgency"},
    {"text": "Order within 3 hours for same-day delivery.", "label": "Urgency"},
    {"text": "Lightning deal: 45 minutes remaining.", "label": "Urgency"},
    {"text": "This week only — buy 2 get 1 free.", "label": "Urgency"},

    # ── Confirmshaming ───────────────────────────────────────────────────────
    {"text": "No thanks, I don't want to save money.", "label": "Confirmshaming"},
    {"text": "No thanks, I prefer paying full price.", "label": "Confirmshaming"},
    {"text": "I don't want exclusive deals.", "label": "Confirmshaming"},
    {"text": "No, I hate free shipping.", "label": "Confirmshaming"},
    {"text": "No thanks, I'm okay with wasting money.", "label": "Confirmshaming"},
    {"text": "I don't want to improve my skills.", "label": "Confirmshaming"},
    {"text": "No thanks, I'll stay uninformed.", "label": "Confirmshaming"},
    {"text": "No, I don't want to protect my family.", "label": "Confirmshaming"},
    {"text": "I don't want to earn cashback rewards.", "label": "Confirmshaming"},
    {"text": "No thanks, I prefer to pay more for flights.", "label": "Confirmshaming"},

    # ── Hidden Costs ─────────────────────────────────────────────────────────
    {"text": "Price does not include taxes and service fees.", "label": "Hidden Costs"},
    {"text": "$49 per night* (*excludes taxes and fees)", "label": "Hidden Costs"},
    {"text": "Booking fee of $8.50 added at checkout.", "label": "Hidden Costs"},
    {"text": "Plus a $5 convenience fee at checkout.", "label": "Hidden Costs"},
    {"text": "Total price before taxes: $120", "label": "Hidden Costs"},
    {"text": "Handling and processing fee applies.", "label": "Hidden Costs"},
    {"text": "Resort fee of $35 per night not included.", "label": "Hidden Costs"},
    {"text": "Additional charges may apply for checked baggage.", "label": "Hidden Costs"},
    {"text": "Price shown excludes VAT.", "label": "Hidden Costs"},
    {"text": "Service fee added at final checkout step.", "label": "Hidden Costs"},

    # ── Forced Action ────────────────────────────────────────────────────────
    {"text": "Create an account to continue shopping.", "label": "Forced Action"},
    {"text": "You must sign up to view the price.", "label": "Forced Action"},
    {"text": "Login required to proceed to checkout.", "label": "Forced Action"},
    {"text": "Sign in to continue. No guest checkout available.", "label": "Forced Action"},
    {"text": "Register to access this content.", "label": "Forced Action"},
    {"text": "Account required to download this file.", "label": "Forced Action"},
    {"text": "You must accept marketing emails to complete purchase.", "label": "Forced Action"},
    {"text": "Subscribe to newsletter to see the deal.", "label": "Forced Action"},
    {"text": "Email required to access the free resource.", "label": "Forced Action"},
    {"text": "Sign up with Facebook to continue.", "label": "Forced Action"},

    # ── Pre-selected Options ─────────────────────────────────────────────────
    {"text": "Add travel insurance $12.99 (pre-selected)", "label": "Pre-selected Options"},
    {"text": "Yes! Keep me subscribed to special offers. (checked by default)", "label": "Pre-selected Options"},
    {"text": "Uncheck this box if you do not wish to receive promotional emails.", "label": "Pre-selected Options"},
    {"text": "Donation of $1 automatically added to your order.", "label": "Pre-selected Options"},
    {"text": "By default you are opted in to our newsletter.", "label": "Pre-selected Options"},
    {"text": "Extended warranty added — uncheck to remove.", "label": "Pre-selected Options"},
    {"text": "Pre-selected: Priority boarding ($15)", "label": "Pre-selected Options"},
    {"text": "Tip (18%) has been automatically added.", "label": "Pre-selected Options"},
    {"text": "By continuing you agree to receive marketing messages.", "label": "Pre-selected Options"},
    {"text": "Seat upgrade pre-selected. Deselect to remove ($9).", "label": "Pre-selected Options"},

    # ── Forced Continuity ────────────────────────────────────────────────────
    {"text": "Start your free trial. Cancel anytime.", "label": "Forced Continuity"},
    {"text": "Free for 30 days, then $9.99/month.", "label": "Forced Continuity"},
    {"text": "Your subscription auto-renews on Dec 1.", "label": "Forced Continuity"},
    {"text": "Your card will be charged $14.99 after the trial.", "label": "Forced Continuity"},
    {"text": "Subscription continues unless you cancel.", "label": "Forced Continuity"},
    {"text": "You will be automatically billed monthly.", "label": "Forced Continuity"},
    {"text": "Free trial ends — billed $19.99 automatically.", "label": "Forced Continuity"},
    {"text": "Recurring charge of $4.99 per week after trial.", "label": "Forced Continuity"},

    # ── Roach Motel ──────────────────────────────────────────────────────────
    {"text": "To cancel your account, call 1-800-XXX-XXXX during business hours.", "label": "Roach Motel"},
    {"text": "Cancellation fee of $25 applies.", "label": "Roach Motel"},
    {"text": "Contact support to cancel your subscription.", "label": "Roach Motel"},
    {"text": "Account deletion requires a 30-day waiting period.", "label": "Roach Motel"},
    {"text": "To close your account please write to us by post.", "label": "Roach Motel"},
    {"text": "Call customer service to cancel — available Mon-Fri 9am-5pm.", "label": "Roach Motel"},

    # ── Normal ────────────────────────────────────────────────────────────────
    {"text": "Welcome to our store. Browse our collection.", "label": "Normal"},
    {"text": "Free delivery on orders over $50.", "label": "Normal"},
    {"text": "Quality products at fair prices.", "label": "Normal"},
    {"text": "Contact us at support@example.com.", "label": "Normal"},
    {"text": "All prices include VAT.", "label": "Normal"},
    {"text": "Subscribe to our newsletter for updates.", "label": "Normal"},
    {"text": "Easy returns within 30 days.", "label": "Normal"},
    {"text": "Customer satisfaction guaranteed.", "label": "Normal"},
    {"text": "Read our privacy policy for details.", "label": "Normal"},
    {"text": "Thank you for your purchase!", "label": "Normal"},
    {"text": "New arrivals every week.", "label": "Normal"},
    {"text": "Shop now and save with our everyday low prices.", "label": "Normal"},
]

LABELS = [
    "Scarcity",
    "Urgency",
    "Confirmshaming",
    "Hidden Costs",
    "Forced Action",
    "Pre-selected Options",
    "Forced Continuity",
    "Roach Motel",
    "Normal",
]

if __name__ == "__main__":
    import pandas as pd
    df = pd.DataFrame(SAMPLES)
    print(df["label"].value_counts())
    print(f"\nTotal samples: {len(df)}")
