# Dataset Guide — How to Collect Screenshots

## Folder Structure

```
dataset/
├── screenshots/
│   ├── scarcity/          ← Put scarcity screenshots here
│   ├── urgency/           ← Urgency screenshots
│   ├── confirmshaming/    ← Confirmshaming screenshots
│   ├── hidden_costs/      ← Hidden cost screenshots
│   ├── forced_action/     ← Forced sign-up screenshots
│   ├── pre_selected/      ← Pre-selected options screenshots
│   ├── forced_continuity/ ← Auto-renewal screenshots
│   ├── roach_motel/       ← Hard-to-cancel screenshots
│   └── normal/            ← Clean, normal website screenshots
├── sample_data.py         ← Text samples for training
├── train_classifier.py    ← Training script
└── DATASET_GUIDE.md       ← This file
```

---

## How to Capture Screenshots

### Tools
- **Windows**: Press `Win + Shift + S` (Snipping Tool)
- **Chrome Extension**: GoFullPage, Fireshot, or Awesome Screenshot
- **Browser DevTools**: Press F12 → right-click → "Capture screenshot"

### What to Capture
Take a screenshot of the specific section of the webpage that contains the dark pattern — not the entire page.

---

## What to Capture per Category

### 1. Scarcity
**Where to find**: Amazon, Booking.com, Airbnb, flight booking sites
**What to capture**:
- "Only X left in stock" messages
- "X people are viewing this" counters
- "Selling fast" badges
**Example websites**:
- `amazon.com` → product pages with low stock warnings
- `booking.com` → hotel pages with "Only 2 left!" text
- `makemytrip.com` → flight/hotel scarcity messages

---

### 2. Urgency
**Where to find**: E-commerce, food delivery, flash sale sites
**What to capture**:
- Countdown timers
- "Today only" banners
- "Order in next X minutes" messages
**Example websites**:
- `flipkart.com` → Big Billion Days countdown
- `myntra.com` → End Of Reason Sale timers
- `swiggy.com` → "Order by X for delivery today"

---

### 3. Confirmshaming
**Where to find**: Newsletter popups, discount popups
**What to capture**:
- The "No thanks, I don't want to save money" type opt-out button
- Popup dialogs with guilt-trip wording
**Example websites**:
- E-commerce newsletter popups
- Any site with "Claim 20% off" / "No thanks, I prefer paying full price"

---

### 4. Hidden Costs
**Where to find**: Checkout pages of booking/e-commerce sites
**What to capture**:
- Final checkout showing added taxes/fees
- "Price does not include X" disclaimers
- Asterisk prices
**Example websites**:
- `irctc.co.in` → ticket booking fee added at checkout
- `bookmyshow.com` → convenience fee at checkout

---

### 5. Forced Action
**Where to find**: Content sites, e-commerce
**What to capture**:
- "Create account to continue" walls
- "Sign in required" gates
- Newsletter-required forms
**Example**: Medium.com paywall, LinkedIn job application requiring signup

---

### 6. Pre-selected Options
**Where to find**: Flight booking, insurance sites, checkout pages
**What to capture**:
- Pre-ticked checkboxes for add-ons
- Insurance/donation added by default
- "Uncheck to remove" items
**Example websites**:
- `makemytrip.com` flight booking → travel insurance pre-added
- `goibibo.com` → seat selection pre-selected

---

### 7. Forced Continuity
**Where to find**: Subscription services
**What to capture**:
- "Free trial then $X/month" disclaimers
- Auto-renewal notices
- "Cancel anytime" (but charges start automatically)
**Example websites**:
- Netflix, Spotify, Amazon Prime trial pages

---

### 8. Roach Motel
**Where to find**: Subscription cancellation flows
**What to capture**:
- Complex cancellation steps
- "Call to cancel" instructions
- Cancellation penalty notices
**Example websites**:
- Gym membership cancellation pages
- Magazine subscription cancellation

---

### 9. Normal (No Dark Pattern)
**Where to find**: Reputable e-commerce sites with clear UX
**What to capture**:
- Clean product pages with no manipulative language
- Clear pricing pages
- Simple "Contact Us" pages
**Example websites**:
- `wikipedia.org`
- Government websites
- University websites

---

## Labeling Format

After collecting screenshots, add the file paths to `labels.json`:

```json
[
  {"file": "screenshots/scarcity/amazon_stock.png", "label": "Scarcity"},
  {"file": "screenshots/urgency/flipkart_timer.png", "label": "Urgency"},
  {"file": "screenshots/normal/wikipedia_home.png",  "label": "Normal"}
]
```

---

## Minimum Recommended Dataset Size

| Category          | Minimum | Recommended |
|---|---|---|
| Scarcity          | 20      | 50          |
| Urgency           | 20      | 50          |
| Confirmshaming    | 15      | 40          |
| Hidden Costs      | 20      | 50          |
| Forced Action     | 15      | 40          |
| Pre-selected      | 15      | 40          |
| Forced Continuity | 15      | 40          |
| Roach Motel       | 10      | 30          |
| Normal            | 30      | 80          |

---

## Naming Convention
Use descriptive filenames:
```
scarcity_amazon_stock_warning.png
urgency_flipkart_sale_countdown.png
normal_wikipedia_homepage.png
```
