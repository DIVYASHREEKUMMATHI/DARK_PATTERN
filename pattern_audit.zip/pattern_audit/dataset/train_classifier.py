"""
Step 1 — Train TF-IDF + Logistic Regression (fast, no GPU needed)
Step 2 — Fine-tune DistilBERT (optional, needs GPU or patience on CPU)

Run Step 1:
    python dataset/train_classifier.py --model tfidf

Run Step 2 (DistilBERT):
    python dataset/train_classifier.py --model distilbert

Output:
    models/tfidf_model.pkl          (Step 1)
    models/distilbert_dark_pattern/ (Step 2)
"""

import os
import sys
import argparse
import pickle

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from sample_data import SAMPLES, LABELS

import re
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.pipeline import Pipeline


# ─────────────────────────────────────────────────────────────────────────────
# Preprocessing
# ─────────────────────────────────────────────────────────────────────────────

def preprocess(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^\w\s'']", " ", text)
    return re.sub(r"\s+", " ", text).strip()


# ─────────────────────────────────────────────────────────────────────────────
# Step 1: TF-IDF + Logistic Regression
# ─────────────────────────────────────────────────────────────────────────────

def train_tfidf():
    print("\n" + "="*60)
    print("  STEP 1: TF-IDF + Logistic Regression")
    print("="*60)

    df  = pd.DataFrame(SAMPLES)
    df["clean"] = df["text"].apply(preprocess)
    X   = df["clean"].tolist()
    y   = df["label"].tolist()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    print(f"\nTrain samples : {len(X_train)}")
    print(f"Test  samples : {len(X_test)}")

    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(
            ngram_range=(1, 3),
            max_features=8000,
            sublinear_tf=True,
            analyzer="word",
        )),
        ("clf", LogisticRegression(
            max_iter=1000,
            C=5.0,
            class_weight="balanced",
            solver="lbfgs",
        )),
    ])

    print("\nTraining model...")
    pipeline.fit(X_train, y_train)

    # ── Cross-validation ──────────────────────────────────────────────────────
    cv_scores = cross_val_score(pipeline, X, y, cv=5, scoring="accuracy")
    print(f"\n5-Fold CV Accuracy : {cv_scores.mean():.2%} +/- {cv_scores.std():.2%}")

    # Test set evaluation
    y_pred = pipeline.predict(X_test)
    print("\n--- Classification Report ---")
    print(classification_report(y_test, y_pred))

    print("--- Confusion Matrix ---")
    cm = confusion_matrix(y_test, y_pred, labels=LABELS)
    cm_df = pd.DataFrame(cm, index=LABELS, columns=LABELS)
    print(cm_df.to_string())

    # Save model
    out_path = os.path.join(os.path.dirname(__file__), "..", "models", "tfidf_model.pkl")
    with open(out_path, "wb") as f:
        pickle.dump(pipeline, f)
    print(f"\nModel saved: {os.path.abspath(out_path)}")

    return pipeline


# ─────────────────────────────────────────────────────────────────────────────
# Step 2: DistilBERT fine-tuning
# ─────────────────────────────────────────────────────────────────────────────

def train_distilbert():
    print("\n" + "="*60)
    print("  STEP 2: DistilBERT Fine-tuning")
    print("="*60)

    try:
        import torch
        from transformers import (
            DistilBertTokenizerFast,
            DistilBertForSequenceClassification,
            Trainer,
            TrainingArguments,
        )
        from torch.utils.data import Dataset
    except ImportError:
        print("ERROR: torch and transformers must be installed.")
        print("Run: pip install torch transformers")
        return

    # ── Dataset class ─────────────────────────────────────────────────────────
    class DarkPatternDataset(Dataset):
        def __init__(self, texts, labels_encoded, tokenizer, max_len=128):
            self.enc = tokenizer(
                texts, truncation=True, padding=True, max_length=max_len
            )
            self.labels = labels_encoded

        def __len__(self):
            return len(self.labels)

        def __getitem__(self, idx):
            item = {k: torch.tensor(v[idx]) for k, v in self.enc.items()}
            item["labels"] = torch.tensor(self.labels[idx])
            return item

    # ── Prepare data ──────────────────────────────────────────────────────────
    df   = pd.DataFrame(SAMPLES)
    label2id = {lbl: i for i, lbl in enumerate(LABELS)}
    id2label = {i: lbl for lbl, i in label2id.items()}

    df["label_id"] = df["label"].map(label2id)
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"].tolist(), df["label_id"].tolist(),
        test_size=0.20, random_state=42, stratify=df["label_id"]
    )

    print(f"\nTrain: {len(X_train)}  Test: {len(X_test)}")
    print(f"Device: {'GPU' if torch.cuda.is_available() else 'CPU (slow — consider GPU)'}")

    # ── Model & tokenizer ─────────────────────────────────────────────────────
    MODEL_NAME = "distilbert-base-uncased"
    tokenizer  = DistilBertTokenizerFast.from_pretrained(MODEL_NAME)
    model      = DistilBertForSequenceClassification.from_pretrained(
        MODEL_NAME,
        num_labels=len(LABELS),
        id2label=id2label,
        label2id=label2id,
    )

    train_ds = DarkPatternDataset(X_train, y_train, tokenizer)
    test_ds  = DarkPatternDataset(X_test,  y_test,  tokenizer)

    # ── Training arguments ────────────────────────────────────────────────────
    out_dir = os.path.join(os.path.dirname(__file__), "..", "models", "distilbert_dark_pattern")

    args = TrainingArguments(
        output_dir=out_dir,
        num_train_epochs=5,
        per_device_train_batch_size=8,
        per_device_eval_batch_size=16,
        warmup_steps=10,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        logging_steps=5,
        report_to="none",
    )

    # ── Metrics ───────────────────────────────────────────────────────────────
    from sklearn.metrics import accuracy_score, f1_score

    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        preds = np.argmax(logits, axis=-1)
        return {
            "accuracy": accuracy_score(labels, preds),
            "f1_macro": f1_score(labels, preds, average="macro"),
        }

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=test_ds,
        compute_metrics=compute_metrics,
    )

    print("\nTraining DistilBERT (this may take 10-30 minutes on CPU)...")
    trainer.train()

    # ── Save ──────────────────────────────────────────────────────────────────
    trainer.save_model(out_dir)
    tokenizer.save_pretrained(out_dir)
    print(f"\nDistilBERT model saved → {os.path.abspath(out_dir)}")

    # ── Final evaluation ──────────────────────────────────────────────────────
    preds_out  = trainer.predict(test_ds)
    y_pred_ids = np.argmax(preds_out.predictions, axis=-1)
    y_pred_lbl = [id2label[i] for i in y_pred_ids]
    y_true_lbl = [id2label[i] for i in y_test]

    print("\n── Final Classification Report ──")
    print(classification_report(y_true_lbl, y_pred_lbl))


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train dark pattern classifier")
    parser.add_argument(
        "--model",
        choices=["tfidf", "distilbert", "both"],
        default="tfidf",
        help="Which model to train (default: tfidf)",
    )
    args = parser.parse_args()

    if args.model in ("tfidf", "both"):
        train_tfidf()

    if args.model in ("distilbert", "both"):
        train_distilbert()
