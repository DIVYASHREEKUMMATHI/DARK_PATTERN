"""
Evaluation script — run after training to see model performance metrics.

Usage:
    python evaluate.py

Outputs:
  - Accuracy, Precision, Recall, F1 Score (per class and overall)
  - Confusion Matrix
  - Sample predictions on 10 test sentences
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import pandas as pd
import numpy as np
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
)
from sklearn.model_selection import train_test_split

from dataset.sample_data import SAMPLES, LABELS
from models.text_classifier import keyword_classify, saved_model_classify, classify_text


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def print_header(title: str):
    print("\n" + "=" * 60)
    print("  " + title)
    print("=" * 60)


def evaluate_on_dataset(predict_fn, X, y_true, model_name: str):
    """Run predictions and print full metrics."""
    print_header(f"Evaluation: {model_name}")

    y_pred = []
    for text in X:
        result = predict_fn(text)
        if result:
            # Pick the highest-confidence detection
            top = max(result, key=lambda d: d["confidence"])
            y_pred.append(top["category"])
        else:
            y_pred.append("Normal")

    # ── Core metrics ─────────────────────────────────────────────────────────
    acc  = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, average="macro", zero_division=0)
    rec  = recall_score(y_true, y_pred, average="macro", zero_division=0)
    f1   = f1_score(y_true, y_pred, average="macro", zero_division=0)

    print(f"\n  Accuracy  : {acc:.2%}")
    print(f"  Precision : {prec:.2%}  (macro)")
    print(f"  Recall    : {rec:.2%}  (macro)")
    print(f"  F1 Score  : {f1:.2%}  (macro)")
    print()

    # ── Per-class report ──────────────────────────────────────────────────────
    print("--- Per-class Classification Report ---")
    print(classification_report(y_true, y_pred, labels=LABELS, zero_division=0))

    # ── Confusion matrix ──────────────────────────────────────────────────────
    print("--- Confusion Matrix ---")
    cm = confusion_matrix(y_true, y_pred, labels=LABELS)
    cm_df = pd.DataFrame(cm, index=LABELS, columns=[l[:6] for l in LABELS])
    print(cm_df.to_string())

    return {"accuracy": acc, "precision": prec, "recall": rec, "f1": f1}


# ─────────────────────────────────────────────────────────────────────────────
# Main evaluation
# ─────────────────────────────────────────────────────────────────────────────

def main():
    df = pd.DataFrame(SAMPLES)
    _, df_test = train_test_split(df, test_size=0.25, random_state=42, stratify=df["label"])

    X_test = df_test["text"].tolist()
    y_test = df_test["label"].tolist()

    print(f"\nTest set size: {len(X_test)} samples")

    results = {}

    # ── 1. Keyword classifier ─────────────────────────────────────────────────
    results["Keyword Rules"] = evaluate_on_dataset(
        keyword_classify, X_test, y_test, "Keyword Rules (no ML)"
    )

    # ── 2. TF-IDF model (if trained) ─────────────────────────────────────────
    from models.text_classifier import _load_saved_model
    if _load_saved_model() is not None:
        results["TF-IDF + LogReg"] = evaluate_on_dataset(
            saved_model_classify, X_test, y_test, "TF-IDF + Logistic Regression"
        )
    else:
        print("\n[TF-IDF model not found] Run: python dataset/train_classifier.py --model tfidf")

    # ── 3. Combined (keyword + TF-IDF) ───────────────────────────────────────
    def combined_fn(text):
        r = classify_text(text, use_saved_model=True)
        return r["detections"]

    results["Combined"] = evaluate_on_dataset(
        combined_fn, X_test, y_test, "Combined (Keyword + TF-IDF)"
    )

    # ── Summary table ─────────────────────────────────────────────────────────
    print_header("Summary Comparison")
    summary = pd.DataFrame(results).T
    summary.columns = ["Accuracy", "Precision", "Recall", "F1"]
    summary = summary.map(lambda x: f"{x:.2%}")
    print(summary.to_string())

    # ── Demo predictions ──────────────────────────────────────────────────────
    print_header("Sample Predictions (live demo)")
    demo_texts = [
        "Only 2 rooms left at this price!",
        "Offer expires in 00:14:30 — act now!",
        "No thanks, I don't want to save money.",
        "Add travel insurance $9.99 (pre-selected)",
        "Create an account to continue shopping.",
        "Price does not include taxes and fees.",
        "Your card will be charged $9.99 after the trial ends.",
        "Contact support to cancel your subscription.",
        "Welcome! Browse our collection of products.",
        "Today only — 50% off everything!",
    ]

    print(f"\n{'Text':<55} {'Prediction':<22} {'Conf':>6}")
    print("-"*88)
    for text in demo_texts:
        result = classify_text(text)
        if result["detections"]:
            top  = result["detections"][0]
            pred = top["category"]
            conf = f"{top['confidence']*100:.0f}%"
        else:
            pred = "Normal"
            conf = " —"
        print(f"{text:<55} {pred:<22} {conf:>6}")


if __name__ == "__main__":
    main()
