"""
Authentication blueprint: register, login, logout.

All routes here are unauthenticated-accessible (they're how you BECOME
authenticated). Everything else in app.py is gated behind @login_required.
"""

import os
import re
import secrets
from urllib.parse import urlencode

import requests
from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app
from flask_login import login_user, logout_user, login_required, current_user
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

from models.user import db, User

auth_bp = Blueprint("auth", __name__)

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

RESET_SALT = "password-reset-salt"
RESET_MAX_AGE_SECONDS = 30 * 60  # 30 minutes


def _serializer():
    return URLSafeTimedSerializer(current_app.secret_key)


def generate_reset_token(user: User) -> str:
    return _serializer().dumps({"uid": user.id}, salt=RESET_SALT)


def verify_reset_token(token: str):
    """Returns the User if the token is valid and unexpired, else None."""
    try:
        data = _serializer().loads(token, salt=RESET_SALT, max_age=RESET_MAX_AGE_SECONDS)
    except (BadSignature, SignatureExpired):
        return None
    return db.session.get(User, data.get("uid"))


def _google_configured():
    return bool(os.environ.get("GOOGLE_CLIENT_ID") and os.environ.get("GOOGLE_CLIENT_SECRET"))


def _google_redirect_uri():
    return os.environ.get("GOOGLE_REDIRECT_URI") or "http://127.0.0.1:5000/login/google/callback"


def _create_google_user(email: str, display_name: str | None = None):
    email = (email or "").strip().lower()
    base_name = (display_name or email.split("@", 1)[0]).strip()
    base_name = re.sub(r"[^A-Za-z0-9_.-]", "_", base_name).strip("_") or "google_user"
    username = base_name
    counter = 1
    while User.query.filter_by(username=username).first():
        username = f"{base_name}{counter}"
        counter += 1

    user = User(username=username, email=email)
    user.set_password(secrets.token_urlsafe(24))
    db.session.add(user)
    db.session.commit()
    return user


@auth_bp.route("/login/google")
def google_login():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    if not _google_configured():
        demo_email = "google.user@example.com"
        user = User.query.filter_by(email=demo_email).first()
        if user is None:
            user = _create_google_user(demo_email, "Google User")
        login_user(user)
        flash("Signed in with Google (demo mode).", "success")
        return redirect(url_for("index"))

    params = {
        "client_id": os.environ["GOOGLE_CLIENT_ID"],
        "redirect_uri": _google_redirect_uri(),
        "response_type": "code",
        "scope": "openid email profile",
        "access_type": "offline",
        "prompt": "consent",
    }
    return redirect("https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(params))


@auth_bp.route("/login/google/callback")
def google_callback():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    error = request.args.get("error")
    if error:
        flash("Google sign-in was cancelled or failed.", "error")
        return redirect(url_for("auth.login"))

    code = request.args.get("code")
    if not code:
        flash("Google sign-in did not return a code.", "error")
        return redirect(url_for("auth.login"))

    if not _google_configured():
        flash("Google login is not configured. Using demo mode instead.", "success")
        user = User.query.filter_by(email="google.user@example.com").first()
        if user is None:
            user = _create_google_user("google.user@example.com", "Google User")
        login_user(user)
        return redirect(url_for("index"))

    token_payload = {
        "code": code,
        "client_id": os.environ["GOOGLE_CLIENT_ID"],
        "client_secret": os.environ["GOOGLE_CLIENT_SECRET"],
        "redirect_uri": _google_redirect_uri(),
        "grant_type": "authorization_code",
    }
    try:
        token_response = requests.post("https://oauth2.googleapis.com/token", data=token_payload, timeout=20)
        token_response.raise_for_status()
        token_data = token_response.json()
        access_token = token_data.get("access_token")
        if not access_token:
            raise ValueError("Missing access token")

        userinfo_response = requests.get(
            "https://openidconnect.googleapis.com/v1/userinfo",
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=20,
        )
        userinfo_response.raise_for_status()
        profile = userinfo_response.json()
    except Exception:
        flash("Unable to complete Google sign-in. Please try again.", "error")
        return redirect(url_for("auth.login"))

    email = (profile.get("email") or "").strip().lower()
    if not email:
        flash("Google did not return an email address for this account.", "error")
        return redirect(url_for("auth.login"))

    user = User.query.filter_by(email=email).first()
    if user is None:
        user = _create_google_user(email, profile.get("name"))

    login_user(user)
    flash("Signed in with Google.", "success")
    return redirect(request.args.get("next") or url_for("index"))


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email    = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm  = request.form.get("confirm_password", "")

        # ── Validation ──────────────────────────────────────────────
        if len(username) < 3:
            flash("Username must be at least 3 characters.", "error")
        elif not EMAIL_RE.match(email):
            flash("Please enter a valid email address.", "error")
        elif len(password) < 8:
            flash("Password must be at least 8 characters.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        elif User.query.filter_by(username=username).first():
            flash("That username is already taken.", "error")
        elif User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "error")
        else:
            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash("Account created — welcome!", "success")
            return redirect(url_for("index"))

        # fall through to re-render form with error flashed
        return render_template("register.html", username=username, email=email)

    return render_template("register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip().lower()
        password   = request.form.get("password", "")
        remember   = request.form.get("remember") == "on"

        user = User.query.filter(
            (db.func.lower(User.username) == identifier) |
            (db.func.lower(User.email) == identifier)
        ).first()

        if user is None or not user.check_password(password):
            flash("Incorrect username/email or password.", "error")
            return render_template("login.html", identifier=identifier)

        login_user(user, remember=remember)
        next_page = request.args.get("next")
        return redirect(next_page or url_for("index"))

    return render_template("login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You've been logged out.", "success")
    return redirect(url_for("auth.login"))


@auth_bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip().lower()
        user = User.query.filter(
            (db.func.lower(User.username) == identifier) |
            (db.func.lower(User.email) == identifier)
        ).first()

        # Always show the same message whether or not the account exists —
        # this avoids leaking which usernames/emails are registered.
        generic_msg = (
            "If an account with that username or email exists, "
            "a password reset link has been generated."
        )

        if user is None:
            flash(generic_msg, "success")
            return render_template("forgot_password.html")

        token = generate_reset_token(user)
        reset_url = url_for("auth.reset_password", token=token, _external=True)

        # ── DEV MODE ──────────────────────────────────────────────
        # No SMTP server is configured in this project, so instead of
        # emailing the link we surface it directly on screen. Wire up
        # a real mail provider (e.g. Flask-Mail + SendGrid/SES) and
        # replace this block with an actual email send before deploying.
        flash(generic_msg, "success")
        return render_template("forgot_password.html", dev_reset_url=reset_url)

    return render_template("forgot_password.html")


@auth_bp.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    user = verify_reset_token(token)
    if user is None:
        flash("That reset link is invalid or has expired. Please request a new one.", "error")
        return redirect(url_for("auth.forgot_password"))

    if request.method == "POST":
        password = request.form.get("password", "")
        confirm  = request.form.get("confirm_password", "")

        if len(password) < 8:
            flash("Password must be at least 8 characters.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        else:
            user.set_password(password)
            db.session.commit()
            flash("Your password has been reset. You can now log in.", "success")
            return redirect(url_for("auth.login"))

        return render_template("reset_password.html", token=token)

    return render_template("reset_password.html", token=token)
