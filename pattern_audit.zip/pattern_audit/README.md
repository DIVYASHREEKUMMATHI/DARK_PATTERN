# Multimodal AI System for Detecting Dark Patterns in Web Interfaces

A college mini-project that combines **Computer Vision**, **NLP**, and **OCR**
to automatically identify deceptive UI/UX patterns (dark patterns) from
webpage screenshots and text.

---

## Features

| Module | Technology | Purpose |
|---|---|---|
| Text Classifier | Keyword rules + zero-shot BART | Detect urgency, scarcity, confirmshaming, etc. |
| Image Analyzer | OpenCV (color + contour analysis) | Detect popups, red/orange urgency colors, badges |
| OCR | Tesseract | Extract text from screenshots automatically |
| Fusion Layer | Weighted confidence merge | Combine text + image signals |
| Web App | Flask + vanilla JS | Upload & analyze interface |

### Detected Dark Pattern Categories
- **Scarcity** – "Only 2 left!"
- **Urgency** – "Offer expires in 5 minutes!"
- **Confirmshaming** – "No thanks, I hate saving money."
- **Forced Continuity** – Auto-renewal traps
- **Hidden Costs** – Fees added at checkout
- **Trick Questions** – Confusing opt-in/out checkboxes
- **Roach Motel** – Easy to join, hard to cancel

---

## Setup

### Prerequisites
- Python 3.10+
- [Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki) installed on your system

### 1. Install Python dependencies
```bash
cd dark_pattern_detector
pip install -r requirements.txt
```

### 2. Install Tesseract OCR (Windows)
Download from: https://github.com/UB-Mannheim/tesseract/wiki
Default install path: `C:\Program Files\Tesseract-OCR\tesseract.exe`

If installed to a different path, set the environment variable before running:
```powershell
$env:TESSERACT_CMD = "C:\path\to\tesseract.exe"
```

### 3. Run the web app
```bash
python app.py
```
Open http://127.0.0.1:5000

---

## Project Structure

```
dark_pattern_detector/
├── app.py                        # Flask web application (main entry point)
├── requirements.txt
├── models/
│   ├── text_classifier.py        # Keyword + zero-shot text classifier
│   ├── image_analyzer.py         # OpenCV-based visual analyzer
│   └── fusion.py                 # Multimodal fusion pipeline
├── dataset/
│   ├── sample_data.py            # Labelled training samples (55 examples)
│   └── train_classifier.py       # TF-IDF + Logistic Regression trainer
├── notebooks/
│   └── dark_pattern_training.ipynb  # Full training & evaluation walkthrough
├── static/
│   ├── css/style.css
│   ├── js/main.js
│   └── uploads/                  # Saved uploaded images (auto-created)
└── templates/
    └── index.html
```

---

## API Endpoints

| Method | Route | Description |
|---|---|---|
| GET | `/` | Main upload page |
| POST | `/analyze` | Analyze screenshot + text, returns JSON |
| GET | `/demo` | Demo with 6 built-in sample texts |

### POST /analyze — Request
`multipart/form-data` fields:
- `screenshot` (optional) — image file (PNG/JPG/…)
- `text` (optional) — raw webpage text
- `use_transformer` (optional) — `"true"` to enable BART zero-shot model

### POST /analyze — Response (JSON)
```json
{
  "dark_pattern_found": true,
  "overall_risk": "High",
  "risk_score": 0.72,
  "detections": [
    {
      "category": "Scarcity",
      "confidence": 0.75,
      "severity": "Medium",
      "source": "text",
      "matched_snippets": ["only 2 rooms left"],
      "description": "Creates false impression of limited availability."
    }
  ],
  "visual_patterns": ["Urgency/Scarcity (red/orange color dominance detected)"],
  "summary": "Dark patterns detected (High risk). Primary concern: Scarcity.",
  "ocr_text": "Only 2 rooms left at this price...",
  "text_method": "keyword"
}
```

---

## Training Your Own Model

```bash
# From the project root
python dataset/train_classifier.py
```

This trains a TF-IDF + Logistic Regression model on the sample dataset
and saves it to `models/tfidf_model.pkl`.

Open `notebooks/dark_pattern_training.ipynb` in Jupyter for a step-by-step
walkthrough with charts and evaluation metrics.

---

## Architecture Diagram

```
Input: Screenshot + Text
         │
    ┌────┴────┐
    │         │
  OCR       Raw Text
  (Tesseract)  │
    │         │
    └────┬────┘
         │
   Text Classifier
   (Keyword Rules / BART)
         │
         ├──────────────────┐
         │                  │
   Image Analyzer      Fusion Layer
   (OpenCV)           (confidence merge)
         │                  │
         └──────────────────┘
                   │
              Final Result
         (category + confidence
          + severity + summary)
```

---

## 4-Week Timeline

| Week | Work |
|---|---|
| 1 | Setup environment, collect real-world screenshots, label them |
| 2 | Run `train_classifier.py`, evaluate in Jupyter notebook |
| 3 | Test the Flask app, improve keyword rules, tune OCR |
| 4 | Polish UI, write project report, prepare demo |

---

## Team / Author
Mini Project — Web Development & AI  
2026
