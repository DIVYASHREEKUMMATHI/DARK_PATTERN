/* ── Pattern Audit – frontend logic ─────────────────────────────── */

const LEGEND_DATA = [
  { name: "Scarcity",            desc: "False sense of limited availability to pressure a purchase." },
  { name: "Urgency",             desc: "Artificial time pressure to force quick decisions." },
  { name: "Confirmshaming",      desc: "Guilt-trip opt-out wording to manipulate users." },
  { name: "Forced Continuity",   desc: "Auto-charges after a free trial without clear notice." },
  { name: "Hidden Costs",        desc: "Extra fees revealed only at the final checkout step." },
  { name: "Trick Questions",     desc: "Confusing opt-in/out checkboxes to mislead consent." },
  { name: "Roach Motel",         desc: "Easy to sign up, deliberately difficult to cancel." },
];

// ── DOM references ────────────────────────────────────────────────────────────
const form            = document.getElementById("analyzeForm");
const dropzone        = document.getElementById("dropzone");
const dzInner         = document.getElementById("dzInner");
const dzPreview       = document.getElementById("dzPreview");
const previewImg      = document.getElementById("previewImg");
const screenshotInput = document.getElementById("screenshotInput");
const removeImgBtn    = document.getElementById("removeImg");
const submitBtn       = document.getElementById("submitBtn");
const btnText         = document.getElementById("btnText");
const btnSpinner      = document.getElementById("btnSpinner");

const resultsSection  = document.getElementById("resultsSection");
const riskBanner      = document.getElementById("riskBanner");
const riskIcon        = document.getElementById("riskIcon");
const riskLabel       = document.getElementById("riskLabel");
const riskSummary     = document.getElementById("riskSummary");
const riskMeter       = document.getElementById("riskMeter");
const riskMeterMarker = document.getElementById("riskMeterMarker");
const riskMeterScore  = document.getElementById("riskMeterScore");
const resultImg       = document.getElementById("resultImg");
const imageCol        = document.getElementById("imageCol");
const detectionCount  = document.getElementById("detectionCount");
const detectionList   = document.getElementById("detectionList");
const sourcePageBox   = document.getElementById("sourcePageBox");
const ocrDetails      = document.getElementById("ocrDetails");
const ocrText         = document.getElementById("ocrText");
const legendGrid      = document.getElementById("legendGrid");
const agentsSection   = document.getElementById("agentsSection");
const agentsGrid      = document.getElementById("agentsGrid");
const errorBox        = document.getElementById("errorBox");
const demoLink        = document.getElementById("demoLink");

// ── Populate legend ───────────────────────────────────────────────────────────
legendGrid.innerHTML = LEGEND_DATA.map(item => `
  <div class="legend-item">
    <h4>${item.name}</h4>
    <p>${item.desc}</p>
  </div>
`).join("");

// ── Drag & drop ───────────────────────────────────────────────────────────────
["dragenter", "dragover"].forEach(e =>
  dropzone.addEventListener(e, ev => { ev.preventDefault(); dropzone.classList.add("drag-over"); })
);
["dragleave", "drop"].forEach(e =>
  dropzone.addEventListener(e, ev => { ev.preventDefault(); dropzone.classList.remove("drag-over"); })
);
dropzone.addEventListener("drop", ev => {
  const file = ev.dataTransfer.files[0];
  if (file) setPreview(file);
});

screenshotInput.addEventListener("change", () => {
  if (screenshotInput.files[0]) setPreview(screenshotInput.files[0]);
});

function setPreview(file) {
  const reader = new FileReader();
  reader.onload = e => {
    previewImg.src = e.target.result;
    dzInner.classList.add("hidden");
    dzPreview.classList.remove("hidden");
  };
  reader.readAsDataURL(file);

  // Sync to input
  const dt = new DataTransfer();
  dt.items.add(file);
  screenshotInput.files = dt.files;
}

removeImgBtn.addEventListener("click", () => {
  screenshotInput.value = "";
  previewImg.src = "";
  dzInner.classList.remove("hidden");
  dzPreview.classList.add("hidden");
});

// ── Form submission ───────────────────────────────────────────────────────────
form.addEventListener("submit", async e => {
  e.preventDefault();
  hideError();
  setLoading(true);
  resultsSection.classList.add("hidden");

  const formData = new FormData(form);

  try {
    const res  = await fetch("/analyze", { method: "POST", body: formData });
    const data = await res.json();

    if (!res.ok || data.error) {
      showError(data.error || "Server error. Please try again.");
      return;
    }

    renderResults(data);
  } catch (err) {
    showError("Network error: " + err.message);
  } finally {
    setLoading(false);
  }
});

// ── Demo link ─────────────────────────────────────────────────────────────────
demoLink.addEventListener("click", async e => {
  e.preventDefault();
  hideError();
  resultsSection.classList.add("hidden");
  setLoading(true);

  try {
    const res  = await fetch("/demo");
    const data = await res.json();
    if (!res.ok) { showError("Demo failed."); return; }
    renderDemoResults(data.demo_results);
  } catch (err) {
    showError("Network error: " + err.message);
  } finally {
    setLoading(false);
  }
});

// ── Render main results ───────────────────────────────────────────────────────
function renderResults(data) {
  const risk    = data.overall_risk || "None";
  const verdict = data.verdict || (risk === "None" ? "Likely Safe" : "Dark Pattern Detected");

  // Risk banner
  riskBanner.className = `risk-banner risk-${risk}`;
  const icons = { High: "🚨", Medium: "⚠️", Low: "ℹ️", None: "✅" };
  const verdictIcons = { "Scam Detected": "🛑", "Dark Pattern Detected": "🚨", "Likely Safe": "✅" };
  riskIcon.textContent  = verdictIcons[verdict] || icons[risk] || "ℹ️";
  riskLabel.textContent = verdict === "Likely Safe" ? "Likely Safe — No Dark Patterns Found" : `${verdict} (${risk} Risk)`;
  riskSummary.textContent = data.summary || "";

  // Risk meter: position marker at risk_score (0.0–1.0) along the gauge
  const score = typeof data.risk_score === "number" ? data.risk_score : 0;
  const pct   = Math.max(0, Math.min(100, score * 100));
  riskMeter.classList.remove("hidden");
  riskMeterMarker.style.left = pct + "%";
  riskMeterScore.innerHTML = `Total risk score: <strong>${pct.toFixed(0)}%</strong>`;

  // Image
  if (data.uploaded_image) {
    // Prefer annotated image if available
    if (data.annotated_image_b64) {
      resultImg.src = "data:image/png;base64," + data.annotated_image_b64;
    } else {
      resultImg.src = data.uploaded_image;
    }
    imageCol.classList.remove("hidden");
  } else {
    imageCol.classList.add("hidden");
  }

  // Detections
  renderDetections(data.detections || []);

  // Source page info (when analyzed via URL)
  renderSourcePage(data);

  // Agent breakdown
  renderAgents(data.agents || []);

  // OCR text
  const ocrStr = (data.ocr_text || "").trim();
  if (ocrStr) {
    ocrText.textContent = ocrStr;
    ocrDetails.classList.remove("hidden");
  } else {
    ocrDetails.classList.add("hidden");
  }

  resultsSection.classList.remove("hidden");
  resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderSourcePage(data) {
  if (!data.source_url) {
    sourcePageBox.classList.add("hidden");
    return;
  }
  sourcePageBox.classList.remove("hidden");
  const buttons = (data.button_labels || []).slice(0, 20)
    .map(b => `<span class="snippet-tag">"${escHtml(b)}"</span>`).join("");
  sourcePageBox.innerHTML = `
    <div class="source-page-header">
      <span class="source-page-icon">🌐</span>
      <div>
        <div class="source-page-title">${escHtml(data.page_title || "Untitled page")}</div>
        <a href="${escHtml(data.source_url)}" target="_blank" rel="noopener noreferrer" class="source-page-url">${escHtml(data.source_url)}</a>
      </div>
    </div>
    ${buttons ? `<div class="source-page-buttons"><span class="source-page-buttons-label">Buttons/links found on page:</span><div class="det-snippets">${buttons}</div></div>` : ""}
  `;
}

function pctBand(pct) {
  if (pct >= 60) return "high";
  if (pct >= 35) return "medium";
  return "low";
}

function renderAgents(agents) {
  if (!agents.length) {
    agentsSection.classList.add("hidden");
    return;
  }
  agentsSection.classList.remove("hidden");

  agentsGrid.innerHTML = agents.map(a => {
    const pct  = typeof a.risk_percentage === "number" ? a.risk_percentage : 0;
    const band = pctBand(pct);
    const findingsHtml = (a.findings && a.findings.length)
      ? `<ul class="agent-findings">${a.findings.map(f => `<li>${escHtml(f)}</li>`).join("")}</ul>`
      : `<p class="agent-empty">${a.ran === false ? "Did not run (no input for this agent)." : "No findings."}</p>`;

    return `
      <div class="agent-card">
        <div class="agent-card-header">
          <span class="agent-name">${escHtml(a.agent)}</span>
          <span class="agent-pct pct-${band}">${pct}%</span>
        </div>
        <div class="agent-bar-track">
          <div class="agent-bar-fill pct-${band}" style="width:${pct}%"></div>
        </div>
        ${findingsHtml}
      </div>
    `;
  }).join("");
}

function renderDetections(detections) {
  detectionCount.textContent = detections.length;
  if (detections.length === 0) {
    detectionList.innerHTML = `<p style="color:var(--text-muted);font-size:.9rem;">No patterns detected. The content appears clean.</p>`;
    return;
  }

  detectionList.innerHTML = detections.map(d => {
    const confPct    = Math.round((d.confidence || 0) * 100);
    const sev        = d.severity || "Low";
    const snippets   = (d.matched_snippets || [])
      .map(s => `<span class="snippet-tag">"${escHtml(s)}"</span>`).join("");
    const fixHtml = d.suggested_fix
      ? `<div class="det-fix">
           <span class="det-fix-label">💡 Suggested replacement</span>
           <p class="det-fix-text">${escHtml(d.suggested_fix)}</p>
         </div>`
      : "";
    return `
      <div class="detection-card sev-${sev}">
        <div class="det-header">
          <span class="det-category">${escHtml(d.category)}</span>
          <span class="det-conf">${confPct}% · ${sev}</span>
        </div>
        <p class="det-desc">${escHtml(d.description || "")}</p>
        ${snippets ? `<div class="det-snippets">${snippets}</div>` : ""}
        ${fixHtml}
      </div>
    `;
  }).join("");
}

// ── Render demo results ───────────────────────────────────────────────────────
function renderDemoResults(results) {
  // Build a synthetic "fused" view from all demo items
  const cards = results.map(r => {
    const risk = r.overall_risk || "None";
    const icons = { High: "🚨", Medium: "⚠️", Low: "ℹ️", None: "✅" };
    const cats  = (r.detections || []).map(d => d.category).join(", ") || "None";
    return `
      <div class="detection-card sev-${risk === "None" ? "Low" : risk}" style="margin-bottom:.6rem;">
        <div class="det-header">
          <span class="det-category">${icons[risk] || ""} ${escHtml(r.text)}</span>
          <span class="det-conf risk-${risk}" style="background:transparent">${risk}</span>
        </div>
        <p class="det-desc">${escHtml(cats)}</p>
      </div>
    `;
  }).join("");

  // Inject into detections column, show section
  riskBanner.className      = "risk-banner risk-High";
  riskIcon.textContent      = "🧪";
  riskLabel.textContent     = "Demo Results";
  riskSummary.textContent   = "Analysis of 6 built-in sample texts.";
  riskMeter.classList.add("hidden");
  imageCol.classList.add("hidden");
  ocrDetails.classList.add("hidden");
  detectionCount.textContent = results.filter(r => r.dark_pattern_found).length + " found";
  detectionList.innerHTML    = cards;
  resultsSection.classList.remove("hidden");
  resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function setLoading(on) {
  submitBtn.disabled = on;
  btnText.textContent = on ? "Analyzing…" : "Analyze";
  btnSpinner.classList.toggle("hidden", !on);
}

function showError(msg) {
  errorBox.textContent = msg;
  errorBox.classList.remove("hidden");
}

function hideError() {
  errorBox.classList.add("hidden");
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
