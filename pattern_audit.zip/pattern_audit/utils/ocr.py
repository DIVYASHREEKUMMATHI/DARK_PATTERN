"""
OCR utility — wraps Tesseract with auto-path detection on Windows.
"""

import os
import sys


def _configure_tesseract():
    """Set pytesseract.tesseract_cmd from env var or common Windows paths."""
    try:
        import pytesseract
    except ImportError:
        return

    env_path = os.environ.get("TESSERACT_CMD")
    if env_path and os.path.isfile(env_path):
        pytesseract.pytesseract.tesseract_cmd = env_path
        return

    if sys.platform == "win32":
        candidates = [
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            r"C:\Users\{}\AppData\Local\Tesseract-OCR\tesseract.exe".format(
                os.environ.get("USERNAME", "")
            ),
        ]
        for path in candidates:
            if os.path.isfile(path):
                pytesseract.pytesseract.tesseract_cmd = path
                return


_configure_tesseract()


def extract_text(image_input) -> str:
    """
    Extract text from an image using Tesseract OCR.
    Accepts: file path (str), PIL Image, or bytes.
    Returns: extracted string (empty if OCR unavailable).
    """
    try:
        import pytesseract
        from PIL import Image as PILImage
        import io

        if isinstance(image_input, str):
            img = PILImage.open(image_input)
        elif isinstance(image_input, (bytes, bytearray)):
            img = PILImage.open(io.BytesIO(image_input))
        else:
            img = image_input  # assume PIL Image

        text = pytesseract.image_to_string(img)
        return text.strip()

    except Exception as exc:
        print(f"[OCR] Could not extract text: {exc}")
        return ""
