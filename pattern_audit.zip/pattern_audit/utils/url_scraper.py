"""
URL Scraper — fetches a real webpage and extracts the text a user would
actually see: paragraphs, headings, button labels, link text, and
placeholder/aria-label strings on interactive elements.

This runs a REAL HTTP request (via `requests`) against whatever URL the
user supplies — no mocking. It's the ingestion step that feeds the
Text Extraction Agent when the user submits a URL instead of a
screenshot or pasted text.
"""

import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse

REQUEST_TIMEOUT = 10
MAX_HTML_BYTES = 3 * 1024 * 1024  # 3 MB cap, avoid huge pages hanging the request

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 PatternAuditBot/1.0"
)

# Tags whose visible text represents an actionable UI element (buttons,
# links, form controls) — these are tracked separately from body text so
# the UI can show "Button/label text found" distinctly from paragraph copy.
INTERACTIVE_SELECTORS = ["button", "a", "input[type=submit]", "input[type=button]",
                          "[role=button]", "label"]

# Tags to strip entirely — scripts/styles never contain user-visible copy.
STRIP_TAGS = ["script", "style", "noscript", "svg", "template"]


class URLFetchError(Exception):
    """Raised when a URL can't be fetched or parsed for analysis."""
    pass


def _validate_url(url: str) -> str:
    url = url.strip()
    if not re.match(r"^https?://", url, re.IGNORECASE):
        url = "https://" + url
    parsed = urlparse(url)
    if not parsed.netloc:
        raise URLFetchError("That doesn't look like a valid URL.")
    return url


def fetch_and_extract(url: str) -> dict:
    """
    Fetches `url` and returns a dict:
      {
        "final_url":     str,   # after redirects
        "page_title":    str,
        "body_text":     str,   # paragraphs, headings, spans, list items
        "button_labels":  [str],  # text found on buttons / link-buttons
        "combined_text": str,   # body_text + button_labels, for the classifier
      }
    Raises URLFetchError on any failure (bad URL, timeout, non-HTML, HTTP error).
    """
    url = _validate_url(url)

    try:
        resp = requests.get(
            url,
            headers={"User-Agent": USER_AGENT},
            timeout=REQUEST_TIMEOUT,
            stream=True,
            allow_redirects=True,
        )
    except requests.exceptions.SSLError:
        raise URLFetchError("SSL certificate error — the site's HTTPS certificate could not be verified.")
    except requests.exceptions.ConnectionError:
        raise URLFetchError("Could not connect to that URL. Check the address and try again.")
    except requests.exceptions.Timeout:
        raise URLFetchError(f"The site took too long to respond (>{REQUEST_TIMEOUT}s).")
    except requests.exceptions.RequestException as exc:
        raise URLFetchError(f"Could not fetch that URL: {exc}")

    if resp.status_code >= 400:
        raise URLFetchError(f"The site returned an error: HTTP {resp.status_code}.")

    content_type = resp.headers.get("Content-Type", "")
    if "text/html" not in content_type and "application/xhtml" not in content_type:
        raise URLFetchError(f"That URL didn't return an HTML page (got '{content_type}').")

    raw = resp.raw.read(MAX_HTML_BYTES + 1, decode_content=True)
    if len(raw) > MAX_HTML_BYTES:
        raise URLFetchError("That page is too large to analyze (>3MB of HTML).")

    html = raw.decode(resp.encoding or "utf-8", errors="replace")
    soup = BeautifulSoup(html, "html.parser")

    for tag in soup(STRIP_TAGS):
        tag.decompose()

    page_title = soup.title.get_text(strip=True) if soup.title else ""

    # ── Button / interactive element labels ─────────────────────────────────
    button_labels = []
    for el in soup.select(", ".join(INTERACTIVE_SELECTORS)):
        text = el.get_text(" ", strip=True)
        if not text:
            # Fall back to common attributes for icon-only buttons
            text = el.get("aria-label") or el.get("value") or el.get("placeholder") or ""
            text = text.strip()
        if text and len(text) <= 200:
            button_labels.append(text)

    # de-dupe while preserving order
    seen = set()
    deduped_buttons = []
    for b in button_labels:
        key = b.lower()
        if key not in seen:
            seen.add(key)
            deduped_buttons.append(b)
    button_labels = deduped_buttons[:100]

    # ── Body text (paragraphs, headings, list items, spans/divs with text) ──
    body_parts = []
    for el in soup.find_all(["p", "h1", "h2", "h3", "h4", "h5", "h6", "li", "span", "div", "strong", "em"]):
        # Skip container elements whose only content is nested tags we'll visit separately
        text = el.find(string=True, recursive=False)
        if text and text.strip():
            body_parts.append(text.strip())

    body_text = " ".join(body_parts)
    body_text = re.sub(r"\s+", " ", body_text).strip()
    body_text = body_text[:20000]  # cap length fed to the classifier

    combined_text = (body_text + " " + " . ".join(button_labels)).strip()

    return {
        "final_url":     resp.url,
        "page_title":    page_title,
        "body_text":     body_text,
        "button_labels": button_labels,
        "combined_text": combined_text,
    }
