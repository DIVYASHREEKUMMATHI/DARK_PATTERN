@echo off
echo ================================================
echo   Pattern Audit - Starting...
echo ================================================
echo.

REM Try to activate venv
if exist ".venv\Scripts\activate.bat" (
    call .venv\Scripts\activate.bat
    echo Virtual environment activated.
) else (
    echo No virtual environment found. Using system Python.
)

echo.
echo Starting Flask app at http://127.0.0.1:5000
echo Press CTRL+C to stop.
echo.
python app.py
pause
