"""
Image-based dark pattern analyzer.
Uses OpenCV to detect visual cues: countdown timers, red/orange urgency colors,
popup overlays, and badge-like "SALE" / "LIMITED" text regions.
"""

import cv2
import numpy as np
from PIL import Image
import io
import base64


# ── Colour masks (HSV ranges) ─────────────────────────────────────────────────

# Red (two HSV ranges because red wraps around 0°)
RED_LOWER1  = np.array([0,   120, 70],  dtype=np.uint8)
RED_UPPER1  = np.array([10,  255, 255], dtype=np.uint8)
RED_LOWER2  = np.array([170, 120, 70],  dtype=np.uint8)
RED_UPPER2  = np.array([180, 255, 255], dtype=np.uint8)

# Orange
ORANGE_LOWER = np.array([11,  120, 70],  dtype=np.uint8)
ORANGE_UPPER = np.array([25,  255, 255], dtype=np.uint8)

# Yellow-green (sale badge colour)
YELLOW_LOWER = np.array([26, 100, 100], dtype=np.uint8)
YELLOW_UPPER = np.array([35, 255, 255], dtype=np.uint8)

# Minimum fraction of image pixels that must match before flagging a colour
COLOR_THRESHOLD = 0.04   # 4 %


def _to_cv2(image_input) -> np.ndarray:
    """Accept file path, bytes, PIL Image, or ndarray and return BGR ndarray."""
    if isinstance(image_input, np.ndarray):
        return image_input
    if isinstance(image_input, Image.Image):
        return cv2.cvtColor(np.array(image_input.convert("RGB")), cv2.COLOR_RGB2BGR)
    if isinstance(image_input, (bytes, bytearray)):
        arr = np.frombuffer(image_input, dtype=np.uint8)
        return cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if isinstance(image_input, str):
        return cv2.imread(image_input)
    raise TypeError(f"Unsupported image type: {type(image_input)}")


def _dominant_color_analysis(img_bgr: np.ndarray) -> dict:
    """Return fraction of pixels in red/orange/yellow ranges."""
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    total = hsv.shape[0] * hsv.shape[1]

    red1  = cv2.inRange(hsv, RED_LOWER1,    RED_UPPER1)
    red2  = cv2.inRange(hsv, RED_LOWER2,    RED_UPPER2)
    red   = cv2.bitwise_or(red1, red2)
    orange = cv2.inRange(hsv, ORANGE_LOWER, ORANGE_UPPER)
    yellow = cv2.inRange(hsv, YELLOW_LOWER, YELLOW_UPPER)

    return {
        "red_fraction":    float(np.count_nonzero(red))    / total,
        "orange_fraction": float(np.count_nonzero(orange)) / total,
        "yellow_fraction": float(np.count_nonzero(yellow)) / total,
    }


def _detect_popup_overlay(img_bgr: np.ndarray) -> bool:
    """
    Heuristic: a popup typically creates a large semi-transparent dark overlay.
    We detect a large rectangular region that is significantly darker than its border.
    """
    gray  = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    h, w  = gray.shape
    edges = cv2.Canny(gray, 50, 150)

    # Look for large closed rectangles
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    img_area = h * w
    for cnt in contours:
        x, y, cw, ch = cv2.boundingRect(cnt)
        area_ratio = (cw * ch) / img_area
        aspect = cw / max(ch, 1)
        # A popup: 10-70 % of image, roughly rectangular
        if 0.10 < area_ratio < 0.70 and 0.3 < aspect < 3.5:
            # Check if inner region is darker (overlay effect)
            inner = gray[y + 10 : y + ch - 10, x + 10 : x + cw - 10]
            border_region = gray[max(0, y-5) : y+5, x : x + cw]
            if inner.size > 0 and border_region.size > 0:
                if np.mean(inner) < np.mean(border_region) - 20:
                    return True
    return False


def _detect_badge_regions(img_bgr: np.ndarray) -> list[dict]:
    """
    Detect small high-saturation badge-like blobs (SALE, %, LIMITED labels).
    Returns list of bounding box dicts.
    """
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    # High-saturation regions
    sat_mask = cv2.inRange(hsv, np.array([0, 150, 100]), np.array([180, 255, 255]))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    sat_mask = cv2.morphologyEx(sat_mask, cv2.MORPH_CLOSE, kernel)

    contours, _ = cv2.findContours(sat_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    h, w = img_bgr.shape[:2]
    badges = []
    for cnt in contours:
        x, y, cw, ch = cv2.boundingRect(cnt)
        area_ratio = (cw * ch) / (h * w)
        aspect = cw / max(ch, 1)
        # Badges are small and roughly square/circular
        if 0.001 < area_ratio < 0.08 and 0.4 < aspect < 2.5:
            badges.append({"x": x, "y": y, "w": cw, "h": ch})
    return badges


def _annotate_image(img_bgr: np.ndarray, signals: dict) -> str:
    """Draw bounding boxes on a copy and return as base64 PNG."""
    annotated = img_bgr.copy()

    for badge in signals.get("badge_regions", []):
        x, y, bw, bh = badge["x"], badge["y"], badge["w"], badge["h"]
        cv2.rectangle(annotated, (x, y), (x + bw, y + bh), (0, 0, 255), 2)
        cv2.putText(annotated, "Badge", (x, max(y - 5, 0)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

    if signals.get("popup_detected"):
        h, w = annotated.shape[:2]
        cv2.putText(annotated, "POPUP OVERLAY DETECTED",
                    (10, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

    _, buf = cv2.imencode(".png", annotated)
    return base64.b64encode(buf).decode("utf-8")


def analyze_image(image_input, annotate: bool = True) -> dict:
    """
    Main entry point for image analysis.

    Returns:
      {
        "signals": {
          "high_urgency_color": bool,
          "popup_detected": bool,
          "badge_regions": [...],
          "color_fractions": {...},
        },
        "visual_dark_patterns": [str],   # human-readable list
        "confidence": float,
        "annotated_image_b64": str | None,
      }
    """
    img = _to_cv2(image_input)
    if img is None:
        return {
            "signals": {},
            "visual_dark_patterns": [],
            "confidence": 0.0,
            "annotated_image_b64": None,
            "error": "Could not decode image",
        }

    # Resize for consistent analysis (keep aspect ratio)
    max_dim = 800
    h, w = img.shape[:2]
    if max(h, w) > max_dim:
        scale = max_dim / max(h, w)
        img = cv2.resize(img, (int(w * scale), int(h * scale)))

    color_data = _dominant_color_analysis(img)
    popup      = _detect_popup_overlay(img)
    badges     = _detect_badge_regions(img)

    urgency_color = (
        color_data["red_fraction"]    > COLOR_THRESHOLD or
        color_data["orange_fraction"] > COLOR_THRESHOLD
    )

    signals = {
        "high_urgency_color": urgency_color,
        "popup_detected":     popup,
        "badge_regions":      badges,
        "color_fractions":    color_data,
    }

    visual_patterns = []
    confidence_sum  = 0.0

    if urgency_color:
        visual_patterns.append("Urgency/Scarcity (red/orange color dominance detected)")
        confidence_sum += 0.60

    if popup:
        visual_patterns.append("Forced Attention (popup/modal overlay detected)")
        confidence_sum += 0.65

    if len(badges) >= 2:
        visual_patterns.append(f"Promotional Badges (found {len(badges)} high-saturation badge regions)")
        confidence_sum += 0.50

    overall_confidence = min(confidence_sum, 0.90) if visual_patterns else 0.0

    annotated_b64 = None
    if annotate and (urgency_color or popup or badges):
        annotated_b64 = _annotate_image(img, signals)

    return {
        "signals":              signals,
        "visual_dark_patterns": visual_patterns,
        "confidence":           round(overall_confidence, 2),
        "annotated_image_b64":  annotated_b64,
    }
