"""
User model + SQLAlchemy database instance for authentication.

Uses SQLite (file-based, zero-config) via Flask-SQLAlchemy, and
Flask-Login for session management. Passwords are never stored in
plain text — only a salted hash (Werkzeug's PBKDF2-SHA256).
"""

from datetime import datetime

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id            = db.Column(db.Integer, primary_key=True)
    username      = db.Column(db.String(80),  unique=True, nullable=False, index=True)
    email         = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)

    # One-to-many: a user can have many past analyses
    analyses = db.relationship(
        "Analysis", backref="user", lazy=True, cascade="all, delete-orphan"
    )

    def set_password(self, raw_password: str) -> None:
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        return check_password_hash(self.password_hash, raw_password)

    def __repr__(self):
        return f"<User {self.username}>"


class Analysis(db.Model):
    """Optional history record: one row per analysis a logged-in user runs."""
    __tablename__ = "analyses"

    id              = db.Column(db.Integer, primary_key=True)
    user_id         = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    input_text      = db.Column(db.Text, nullable=True)
    overall_risk    = db.Column(db.String(20), nullable=True)
    dark_pattern    = db.Column(db.Boolean, default=False)
    created_at      = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Analysis {self.id} user={self.user_id}>"
