"""
Text-based dark pattern classifier.

Two modes:
  1. keyword_classify()   — fast rule-based (works offline, no ML needed)
  2. bert_classify()      — DistilBERT fine-tuned model (loads tfidf_model.pkl or bert model)
  3. classify_text()      — main entry point, uses keyword by default
"""

import re
import os

# ─────────────────────────────────────────────────────────────────────────────
# Dark pattern keyword rules — one dict entry per category
# Each value is a list of regex patterns (case-insensitive)
# ─────────────────────────────────────────────────────────────────────────────

PATTERN_RULES = {

    "Scarcity": [
        r"\bonly\s+\d+\s+(items?|rooms?|seats?|tickets?|left|remaining|available|in\s+stock)\b",
        r"\b(limited\s+(stock|availability|supply|edition|time\s+offer))\b",
        r"\b(almost\s+gone|selling\s+fast|last\s+chance|nearly\s+sold\s+out|going\s+fast)\b",
        r"\bhurry[,!]?\s*(only|just|grab)\b",
        r"\d+\s+(people?\s+are\s+(viewing|watching)|others?\s+(looking|viewing))",
        r"\b(low\s+stock|few\s+left|last\s+(one|few|item|unit)s?)\b",
    ],

    "Urgency": [
        r"\boffer\s+(ends?|expires?|expiring|ending)\b",
        r"\b(deal\s+ends?|expires?\s+in|ending\s+soon|time\s+is\s+running\s+out)\b",
        r"\b(today\s+only|tonight\s+only|this\s+week\s+only|flash\s+sale|lightning\s+deal)\b",
        r"\b\d+\s*(hours?|minutes?|seconds?|hrs?|mins?|secs?)\s*(left|remaining|only|to\s+go)\b",
        r"\b(countdown|timer|ticking)\b",
        r"\bact\s+now\b",
        r"\bdon[''']?t\s+(miss|wait|delay)\b",
        r"\b(order\s+within|buy\s+within)\s+\d+\s*(hours?|minutes?)\b",
    ],

    "Confirmshaming": [
        r"\bno\s+thanks?,?\s+i\s+(don[''']?t\s+want|hate|prefer\s+not|like\s+paying|enjoy)\b",
        r"\bi\s+(don[''']?t\s+want|hate|prefer\s+not)\s+to\s+(save|get|have|be|improve|learn)\b",
        r"\bno\s+thanks?,?\s+i\s+(like\s+paying|am\s+okay\s+paying|enjoy\s+paying)\b",
        r"\bi[''']m\s+(okay|fine|happy)\s+(paying|with|to\s+miss)\b",
        r"\bno[,\s]+i\s+(already|don[''']?t|prefer|hate)\b",
        r"\bno\s+thanks?,?\s+i\s+don[''']?t\s+want\s+to\s+(save|protect|improve|earn)\b",
    ],

    "Hidden Costs": [
        r"\b(fees?\s+(not\s+included|apply|added\s+at\s+checkout|extra))\b",
        r"\b(taxes?\s+and\s+fees?\s+extra|plus\s+taxes?\s+and\s+fees?|taxes?\s+not\s+included)\b",
        r"\bexclude[sd]?\s+(taxes?|fees?|shipping|vat)\b",
        r"\b(handling\s+fee|service\s+fee|convenience\s+fee|booking\s+fee|resort\s+fee)\b",
        r"\b(before\s+tax|excl\.?\s*tax|\\*see\s+details|\*\s*terms\s+apply)\b",
        r"\badditional\s+(charges?|fees?|costs?)\s+(apply|may\s+apply)\b",
        r"\bprice\s+(shown|displayed)\s+(does\s+not|doesn[''']?t)\s+include\b",
    ],

    "Forced Action": [
        r"\b(must\s+(sign\s+up|register|create\s+an?\s+account|subscribe)|required\s+to\s+sign\s+up)\b",
        r"\b(create\s+an?\s+account\s+to\s+(continue|proceed|checkout|buy))\b",
        r"\b(sign\s+in\s+to\s+continue|login\s+required|account\s+required)\b",
        r"\b(forced\s+(sign.?up|registration|subscription))\b",
        r"\b(you\s+must\s+accept|you\s+must\s+agree|must\s+opt.?in)\b",
        r"\b(newsletter\s+sign.?up\s+required|email\s+required\s+to\s+(access|download|continue))\b",
        r"\bcontinue\s+as\s+guest\b",
    ],

    "Pre-selected Options": [
        r"\b(pre.?selected|pre.?checked|already\s+selected|automatically\s+selected)\b",
        r"\b(add\s+travel\s+insurance|add\s+protection|add\s+warranty)\s*[\(\[]?\$?\d",
        r"\byes[,!]?\s+(add|include|sign\s+me\s+up|keep\s+me)\b",
        r"\b(opt.?out|uncheck|untick|deselect)\s+(to\s+)?remove\b",
        r"\bby\s+(default|clicking|continuing|proceeding)\s+you\s+(agree|consent|accept)\b",
        r"\b(donation\s+added|tip\s+added|insurance\s+added)\s*(automatically|by\s+default)\b",
        r"\buncheck\s+(this\s+)?(box|option)\s+(if\s+you\s+(do\s+not|don[''']?t))\b",
    ],

    "Forced Continuity": [
        r"\b(free\s+trial.*then|try\s+free.*after|free\s+for\s+\d+\s+days)\b",
        r"\bauto.?renew(s|ed|al|ing)?\b",
        r"\b(subscription\s+will\s+continue|will\s+be\s+charged\s+after|charged\s+after\s+trial)\b",
        r"\b(charged\s+automatically|recurring\s+charge|billed\s+monthly|billed\s+annually)\b",
        r"\byour\s+card\s+will\s+be\s+charged\b",
    ],

    "Roach Motel": [
        r"\bcontact\s+(support|us|customer\s+service)\s+to\s+(cancel|delete|close)\b",
        r"\bcall\s+.*(cancel|unsubscribe|close\s+account)\b",
        r"\bcancell?ation\s+(fee|penalty|charge|cost)\b",
        r"\b(hard\s+to\s+cancel|difficult\s+to\s+cancel|not\s+easy\s+to\s+cancel)\b",
        r"\b(close\s+account|delete\s+account|deactivate\s+account)\b",
    ],
}

CATEGORY_INFO = {
    "Scarcity": {
        "description": "Creates a false impression of limited availability to pressure users into buying.",
        "example": "\"Only 2 seats left!\"",
        "severity": "High",
        "suggested_fix": "Show real, accurate stock levels only — or remove the claim entirely if quantity isn't actually limited.",
    },
    "Urgency": {
        "description": "Applies artificial time pressure to force quick decisions without thinking.",
        "example": "\"Offer ends in 00:10:00\"",
        "severity": "High",
        "suggested_fix": "\"Prices may change without notice\" — drop fake countdowns and let users decide at their own pace.",
    },
    "Confirmshaming": {
        "description": "Guilt-trips users into opting in by making the opt-out button sound bad.",
        "example": "\"No thanks, I hate saving money.\"",
        "severity": "Medium",
        "suggested_fix": "\"No thanks\" — a neutral opt-out with no guilt language.",
    },
    "Hidden Costs": {
        "description": "Reveals extra fees, taxes, or charges only at the final checkout step.",
        "example": "\"Price excludes taxes and service fees.\"",
        "severity": "High",
        "suggested_fix": "\"Total price: $X, including all taxes and fees\" — show the final price up front.",
    },
    "Forced Action": {
        "description": "Forces users to create an account, subscribe, or complete an unrelated action to proceed.",
        "example": "\"Create an account to continue.\"",
        "severity": "Medium",
        "suggested_fix": "\"Continue as guest\" — offer an account-free path alongside sign-up.",
    },
    "Pre-selected Options": {
        "description": "Automatically checks boxes or selects options the user did not choose.",
        "example": "\"Add travel insurance $12.99 (pre-selected)\"",
        "severity": "High",
        "suggested_fix": "Leave add-ons unchecked by default — require an explicit opt-in click.",
    },
    "Forced Continuity": {
        "description": "Signs users up for recurring charges after a free trial without clear notice.",
        "example": "\"Free for 30 days, then $9.99/month auto-billed.\"",
        "severity": "High",
        "suggested_fix": "\"Free for 30 days. We'll email you 3 days before your trial ends and charge $9.99/month if you don't cancel.\"",
    },
    "Roach Motel": {
        "description": "Makes it easy to sign up but deliberately difficult to cancel or leave.",
        "example": "\"Call customer service to cancel.\"",
        "severity": "Medium",
        "suggested_fix": "\"Cancel anytime from your account settings\" — make cancellation as easy as sign-up.",
    },
}

ALL_CATEGORIES = list(PATTERN_RULES.keys())


# ─────────────────────────────────────────────────────────────────────────────
# Trust signals — phrases that indicate genuinely transparent design.
# If one of these appears and the ONLY evidence for a category is a weak
# signal (e.g. from the noisy ML model), we treat it as a false positive
# and drop that detection rather than penalize honest, clearly-worded pages.
# ─────────────────────────────────────────────────────────────────────────────

TRUST_SIGNALS = {
    "Forced Continuity":    [r"\bcancel\s+anytime\b", r"\beasy\s+to\s+cancel\b",
                              r"\bno\s+commitment\b", r"\bcancel\s+at\s+any\s+time\b"],
    "Roach Motel":          [r"\bcancel\s+anytime\b", r"\beasy\s+to\s+cancel\b",
                              r"\bone.?click\s+cancel(lation)?\b", r"\bcancel\s+in\s+(one|1)\s+click\b"],
    "Hidden Costs":         [r"\ball\s+(fees|taxes)\s+included\b", r"\bno\s+hidden\s+fees\b",
                              r"\btransparent\s+pricing\b", r"\bfinal\s+price\s+shown\b"],
    "Pre-selected Options": [r"\bnothing\s+is\s+pre.?selected\b", r"\byou\s+choose\s+what\s+to\s+add\b",
                              r"\ball\s+options?\s+unchecked\s+by\s+default\b"],
    "Forced Action":        [r"\bcontinue\s+as\s+guest\b", r"\bno\s+account\s+(needed|required)\b",
                              r"\bsign\s*up\s+optional\b"],
}

# Confidence below which a trust-signal match will suppress the detection.
# Strong keyword-rule hits (multiple matches) exceed this and are kept —
# a trust phrase can't cancel out clear, explicit dark-pattern language.
TRUST_SUPPRESSION_CEILING = 0.75


def _has_trust_signal(clean_text: str, category: str) -> bool:
    for pat in TRUST_SIGNALS.get(category, []):
        if re.search(pat, clean_text, re.IGNORECASE):
            return True
    return False


# ─────────────────────────────────────────────────────────────────────────────
# Helper: text cleaning
# ─────────────────────────────────────────────────────────────────────────────

def _preprocess(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^\w\s''.,%!$]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


# ─────────────────────────────────────────────────────────────────────────────
# Mode 1: Keyword / Rule-based classifier
# ─────────────────────────────────────────────────────────────────────────────

def keyword_classify(text: str) -> list:
    """
    Fast offline classifier using regex rules.

    Returns a list of dicts:
      { category, confidence, matched_snippets, description, example, severity }
    """
    clean      = _preprocess(text)
    detections = []

    for category, patterns in PATTERN_RULES.items():
        hits = []
        for pat in patterns:
            for m in re.finditer(pat, clean, re.IGNORECASE):
                snippet = m.group(0).strip()
                if snippet not in hits:
                    hits.append(snippet)

        if hits:
            # More matches → higher confidence (capped at 0.95)
            confidence = min(0.55 + 0.10 * len(hits), 0.95)
            info = CATEGORY_INFO[category]
            detections.append({
                "category":         category,
                "confidence":       round(confidence, 2),
                "matched_snippets": hits[:5],
                "description":      info["description"],
                "example":          info["example"],
                "severity":         info["severity"],
                "suggested_fix":    info.get("suggested_fix", ""),
            })

    return detections


# ─────────────────────────────────────────────────────────────────────────────
# Mode 2: Saved TF-IDF / DistilBERT model
# ─────────────────────────────────────────────────────────────────────────────

_saved_model = None
_saved_model_load_attempted = False

def _load_saved_model():
    """
    Loads the trained TF-IDF + LogReg model from tfidf_model.pkl.

    Returns None (instead of raising) if the file is missing, corrupted,
    or was pickled with an incompatible library version — e.g. a numpy
    2.x pickle loaded under numpy 1.x raises
    `ModuleNotFoundError: No module named 'numpy._core.numeric'`.
    In all of these cases we fall back to the keyword-only classifier
    rather than crashing the whole analysis request.
    """
    global _saved_model, _saved_model_load_attempted

    if _saved_model is not None:
        return _saved_model
    if _saved_model_load_attempted:
        # Already tried and failed this process — don't retry every request.
        return None

    _saved_model_load_attempted = True

    model_path = os.path.join(os.path.dirname(__file__), "tfidf_model.pkl")
    if not os.path.isfile(model_path):
        return None

    import pickle
    try:
        with open(model_path, "rb") as f:
            _saved_model = pickle.load(f)
        return _saved_model
    except Exception as exc:
        print(
            f"[text_classifier] Could not load tfidf_model.pkl ({exc}). "
            "Falling back to keyword-only classification. This usually means "
            "the pickle was saved with a different numpy/scikit-learn version "
            "than what's installed — retrain the model or match versions to fix."
        )
        return None


def saved_model_classify(text: str) -> list:
    """
    Uses the trained TF-IDF + LogReg model saved by train_classifier.py.
    Falls back gracefully to empty list if model not found.
    """
    model = _load_saved_model()
    if model is None:
        return []

    try:
        clean = _preprocess(text)
        # predict_proba gives probabilities for all classes
        proba  = model.predict_proba([clean])[0]
        labels = model.classes_
        results = []
        for label, prob in zip(labels, proba):
            if label == "Normal":
                continue
            if prob >= 0.55:
                info = CATEGORY_INFO.get(label, {})
                results.append({
                    "category":         label,
                    "confidence":       round(float(prob), 2),
                    "matched_snippets": [],
                    "description":      info.get("description", ""),
                    "example":          info.get("example", ""),
                    "severity":         info.get("severity", "Medium"),
                    "suggested_fix":    info.get("suggested_fix", ""),
                })
        return sorted(results, key=lambda x: x["confidence"], reverse=True)
    except Exception as exc:
        print(f"[saved_model_classify] error: {exc}")
        return []


# ─────────────────────────────────────────────────────────────────────────────
# Mode 3: Zero-shot transformer (BERT / BART)
# ─────────────────────────────────────────────────────────────────────────────

_zero_shot = None

def _load_zero_shot():
    global _zero_shot
    if _zero_shot is None:
        from transformers import pipeline
        _zero_shot = pipeline(
            "zero-shot-classification",
            model="facebook/bart-large-mnli",
        )
    return _zero_shot


def transformer_classify(text: str, threshold: float = 0.28) -> list:
    """
    Zero-shot classification using BART-MNLI (no training data needed).
    Requires `transformers` and `torch` to be installed.
    """
    try:
        clf = _load_zero_shot()
    except Exception as exc:
        print(f"[transformer] not available: {exc}")
        return []

    candidate_labels = ALL_CATEGORIES + ["Normal / No Dark Pattern"]
    max_chars  = 512
    chunks     = [text[i:i + max_chars] for i in range(0, min(len(text), 2048), max_chars)]
    cat_scores: dict = {}

    for chunk in chunks:
        result = clf(chunk, candidate_labels, multi_label=True)
        for label, score in zip(result["labels"], result["scores"]):
            cat_scores[label] = max(cat_scores.get(label, 0.0), score)

    detections = []
    for cat, score in cat_scores.items():
        if cat == "Normal / No Dark Pattern":
            continue
        if score >= threshold:
            info = CATEGORY_INFO.get(cat, {})
            detections.append({
                "category":         cat,
                "confidence":       round(score, 2),
                "matched_snippets": [],
                "description":      info.get("description", ""),
                "example":          info.get("example", ""),
                "severity":         info.get("severity", "Medium"),
                "suggested_fix":    info.get("suggested_fix", ""),
            })

    return sorted(detections, key=lambda x: x["confidence"], reverse=True)


# ─────────────────────────────────────────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────────────────────────────────────────

def classify_text(
    text: str,
    use_transformer: bool = False,
    use_saved_model: bool = True,
) -> dict:
    """
    Classify text for dark patterns.

    Args:
        text            : raw text to classify
        use_transformer : run BART zero-shot (slow, needs torch)
        use_saved_model : use trained TF-IDF model if available

    Returns dict:
      {
        dark_pattern_found : bool,
        detections         : list of detection dicts,
        method             : "keyword" | "combined" | "transformer",
        clean_text         : str,
      }
    """
    if not text or not text.strip():
        return {
            "dark_pattern_found": False,
            "detections":         [],
            "method":             "keyword",
            "clean_text":         "",
        }

    # Always run keyword rules
    kw_results = keyword_classify(text)

    # Merge with saved ML model if available
    if use_saved_model:
        ml_results = saved_model_classify(text)
        merged: dict = {d["category"]: d for d in kw_results}
        for d in ml_results:
            cat = d["category"]
            if cat not in merged or d["confidence"] > merged[cat]["confidence"]:
                merged[cat] = d
        kw_results = list(merged.values())

    # Optionally add transformer results
    if use_transformer:
        tr_results = transformer_classify(text)
        merged = {d["category"]: d for d in kw_results}
        for d in tr_results:
            cat = d["category"]
            if cat not in merged or d["confidence"] > merged[cat]["confidence"]:
                merged[cat] = d
        detections = sorted(merged.values(), key=lambda x: x["confidence"], reverse=True)
        method = "combined"
    else:
        detections = sorted(kw_results, key=lambda x: x["confidence"], reverse=True)
        method = "keyword" if not use_saved_model else "combined"

    # ── Trust-signal suppression ──────────────────────────────────────────────
    # Drop weak detections (< TRUST_SUPPRESSION_CEILING confidence) for
    # categories where the text also contains an explicit trust/transparency
    # phrase (e.g. "cancel anytime"). Strong, high-confidence keyword hits
    # survive — a trust phrase doesn't excuse blatant, repeated dark-pattern
    # language elsewhere in the same text.
    clean_for_trust = _preprocess(text)
    detections = [
        d for d in detections
        if not (
            d["confidence"] < TRUST_SUPPRESSION_CEILING
            and _has_trust_signal(clean_for_trust, d["category"])
        )
    ]

    return {
        "dark_pattern_found": len(detections) > 0,
        "detections":         detections,
        "method":             method,
        "clean_text":         _preprocess(text),
    }
