"""
Multimodal fusion layer.
Combines text-classifier results + image-analyzer results into one final output.
"""

from models.text_classifier import classify_text
from models.image_analyzer  import analyze_image


def _severity_label(confidence: float) -> str:
    if confidence >= 0.80:
        return "High"
    if confidence >= 0.55:
        return "Medium"
    return "Low"


def fuse_results(text_result: dict, image_result: dict) -> dict:
    """
    Merge text detections with image detections.

    Boosting rules:
    - If image shows red/orange urgency colors → boost Urgency + Scarcity by +10%
    - If image shows popup overlay            → boost Forced Action + Forced Continuity by +10%
    - If image shows promotional badges       → boost Scarcity + Hidden Costs by +10%
    """

    # ── Map image signals to text categories ──────────────────────────────────
    image_category_signals: set = set()
    signals = image_result.get("signals", {})

    if signals.get("high_urgency_color"):
        image_category_signals.update({"Urgency", "Scarcity"})
    if signals.get("popup_detected"):
        image_category_signals.update({"Forced Action", "Forced Continuity", "Roach Motel"})
    if signals.get("badge_regions"):
        image_category_signals.update({"Scarcity", "Hidden Costs", "Pre-selected Options"})

    # ── Merge: start from text detections, boost with image ──────────────────
    seen: set      = set()
    detections: list = []

    for det in text_result.get("detections", []):
        cat  = det["category"]
        conf = det["confidence"]

        boost  = 0.10 if cat in image_category_signals else 0.0
        conf   = min(conf + boost, 0.97)
        source = "text+image" if boost else "text"

        detections.append({
            "category":         cat,
            "confidence":       round(conf, 2),
            "severity":         _severity_label(conf),
            "source":           source,
            "matched_snippets": det.get("matched_snippets", []),
            "description":      det.get("description", ""),
            "example":          det.get("example", ""),
            "suggested_fix":    det.get("suggested_fix", ""),
        })
        seen.add(cat)

    # ── Add image-only visual patterns not covered by text ────────────────────
    for vp in image_result.get("visual_dark_patterns", []):
        if "Urgency" in vp or "Scarcity" in vp:
            cat = "Urgency/Scarcity (Visual)"
        elif "Popup" in vp or "Forced" in vp:
            cat = "Forced Action (Visual)"
        elif "Badge" in vp or "Promotional" in vp:
            cat = "Promotional Pressure (Visual)"
        else:
            cat = "Visual Dark Pattern"

        if cat not in seen:
            img_conf = image_result.get("confidence", 0.50)
            detections.append({
                "category":         cat,
                "confidence":       round(img_conf, 2),
                "severity":         _severity_label(img_conf),
                "source":           "image",
                "matched_snippets": [],
                "description":      vp,
                "example":          "",
            })
            seen.add(cat)

    # Sort by confidence
    detections.sort(key=lambda x: x["confidence"], reverse=True)

    # ── Overall risk score ────────────────────────────────────────────────────
    top_confs = [d["confidence"] for d in detections[:3]]
    if top_confs:
        weights   = [0.50, 0.30, 0.20]
        risk_score = sum(w * c for w, c in zip(weights, top_confs + [0] * 3))
    else:
        risk_score = 0.0

    risk_score = round(min(risk_score, 1.0), 2)

    if risk_score >= 0.60:
        overall_risk = "High"
    elif risk_score >= 0.35:
        overall_risk = "Medium"
    elif risk_score > 0.0:
        overall_risk = "Low"
    else:
        overall_risk = "None"

    # ── Human-readable summary ────────────────────────────────────────────────
    if detections:
        top  = detections[0]
        cats = ", ".join(d["category"] for d in detections[:3])
        summary = (
            f"Dark patterns detected ({overall_risk} risk). "
            f"Primary concern: {top['category']} "
            f"({top['confidence']*100:.0f}% confidence). "
            f"Categories found: {cats}."
        )
    else:
        summary = "No dark patterns detected. The interface appears clean."

    return {
        "dark_pattern_found": len(detections) > 0,
        "overall_risk":       overall_risk,
        "risk_score":         risk_score,
        "detections":         detections,
        "visual_patterns":    image_result.get("visual_dark_patterns", []),
        "summary":            summary,
    }


def analyze(
    image_input=None,
    raw_text: str = "",
    use_ocr: bool = True,
    use_transformer: bool = False,
    use_saved_model: bool = True,
) -> dict:
    """
    Full multimodal pipeline:
      OCR (optional) → Text Classify → Image Analyze → Fuse → Result

    Args:
        image_input     : file path (str), bytes, PIL Image, or None
        raw_text        : pre-supplied text (skips OCR when provided)
        use_ocr         : run Tesseract OCR if raw_text is empty
        use_transformer : run BART zero-shot transformer
        use_saved_model : use trained TF-IDF model if available

    Returns merged result dict from fuse_results() plus:
        ocr_text            : str — text extracted from image
        annotated_image_b64 : str | None — base64 annotated PNG
        text_method         : str — which classifier was used
    """
    ocr_text = raw_text

    # ── OCR ───────────────────────────────────────────────────────────────────
    if use_ocr and image_input is not None and not raw_text.strip():
        try:
            from utils.ocr import extract_text
            ocr_text = extract_text(image_input)
        except Exception as exc:
            ocr_text = ""
            print(f"[OCR] Warning: {exc}")

    # ── Text classification ───────────────────────────────────────────────────
    text_result = classify_text(
        ocr_text,
        use_transformer=use_transformer,
        use_saved_model=use_saved_model,
    )

    # ── Image analysis ────────────────────────────────────────────────────────
    if image_input is not None:
        image_result = analyze_image(image_input, annotate=True)
    else:
        image_result = {
            "signals":              {},
            "visual_dark_patterns": [],
            "confidence":           0.0,
            "annotated_image_b64":  None,
        }

    # ── Fusion ────────────────────────────────────────────────────────────────
    fused = fuse_results(text_result, image_result)
    fused["ocr_text"]            = ocr_text
    fused["annotated_image_b64"] = image_result.get("annotated_image_b64")
    fused["text_method"]         = text_result.get("method", "keyword")

    return fused
