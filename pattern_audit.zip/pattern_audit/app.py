"""
Flask web application for Pattern Audit.
Routes:
  GET  /           → upload page
  POST /analyze    → run full multimodal pipeline, return JSON
  GET  /demo       → run demo with built-in sample texts
"""

import os
import sys
import io
import json
import base64
import uuid
import secrets

from flask import (
    Flask, request, render_template, jsonify, send_from_directory
)
from werkzeug.utils import secure_filename
from PIL import Image
from flask_login import (
    LoginManager, login_required, current_user
)

# Make sure sibling packages are importable when running app.py directly
sys.path.insert(0, os.path.dirname(__file__))

from agents.pipeline import run_pipeline
from models.user import db, User, Analysis
from auth import auth_bp
from utils.url_scraper import fetch_and_extract, URLFetchError

# ── App config ─────────────────────────────────────────────────────────────────

BASE_DIR        = os.path.dirname(__file__)
UPLOAD_FOLDER   = os.path.join(BASE_DIR, "static", "uploads")
INSTANCE_DIR    = os.path.join(BASE_DIR, "instance")
ALLOWED_EXT     = {"png", "jpg", "jpeg", "gif", "bmp", "webp"}
MAX_CONTENT_MB  = 10

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(INSTANCE_DIR, exist_ok=True)

app = Flask(__name__)
app.config["UPLOAD_FOLDER"]      = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_MB * 1024 * 1024

# Secret key: load from env var in production; auto-generate + persist
# a local one for dev so sessions survive restarts.
_secret_path = os.path.join(INSTANCE_DIR, "secret.key")
if os.environ.get("SECRET_KEY"):
    app.secret_key = os.environ["SECRET_KEY"]
elif os.path.exists(_secret_path):
    app.secret_key = open(_secret_path).read().strip()
else:
    key = secrets.token_hex(32)
    with open(_secret_path, "w") as f:
        f.write(key)
    app.secret_key = key

# ── Database (SQLite) ────────────────────────────────────────────────────────
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(INSTANCE_DIR, "app.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# ── Login manager ────────────────────────────────────────────────────────────
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message = "Please log in to use the detector."
login_manager.login_message_category = "error"
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


app.register_blueprint(auth_bp)

with app.app_context():
    db.create_all()


def _allowed(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


# ── Routes ─────────────────────────────────────────────────────────────────────

@app.route("/")
@login_required
def index():
    return render_template("index.html", user=current_user)


@app.route("/analyze", methods=["POST"])
@login_required
def analyze_route():
    """
    Accepts multipart/form-data with:
      - screenshot  (optional file)
      - text        (optional textarea)
      - url         (optional website URL to fetch and analyze live)
      - use_transformer (optional checkbox, "true"/"false")
    Returns JSON result.
    """
    raw_text        = request.form.get("text", "").strip()
    url_input       = request.form.get("url", "").strip()
    use_transformer = request.form.get("use_transformer", "false").lower() == "true"
    image_input     = None
    saved_filename  = None
    page_info       = None

    # Handle uploaded file
    file = request.files.get("screenshot")
    if file and file.filename and _allowed(file.filename):
        filename       = secure_filename(f"{uuid.uuid4().hex}_{file.filename}")
        save_path      = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(save_path)
        saved_filename = filename
        image_input    = save_path

    # Handle URL: fetch the live page and extract its visible text +
    # button/link labels, then feed that into the same text pipeline.
    if url_input:
        try:
            page_info = fetch_and_extract(url_input)
        except URLFetchError as exc:
            return jsonify({"error": str(exc)}), 400
        except Exception as exc:
            return jsonify({"error": f"Unexpected error fetching URL: {exc}"}), 500

        # Combine scraped copy with anything the user also typed manually
        raw_text = (page_info["combined_text"] + " " + raw_text).strip()

    # Need at least image, text, or a URL
    if image_input is None and not raw_text:
        return jsonify({"error": "Please provide a screenshot, text, or a URL."}), 400

    try:
        result = run_pipeline(
            image_input=image_input,
            raw_text=raw_text,
            use_ocr=(image_input is not None),
            use_transformer=use_transformer,
        )
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

    result["uploaded_image"] = (
        f"/static/uploads/{saved_filename}" if saved_filename else None
    )

    if page_info:
        result["source_url"]       = page_info["final_url"]
        result["page_title"]       = page_info["page_title"]
        result["button_labels"]    = page_info["button_labels"]

    # Save a lightweight history record for this user
    try:
        record = Analysis(
            user_id=current_user.id,
            input_text=(url_input or raw_text)[:2000] if (url_input or raw_text) else None,
            overall_risk=result.get("overall_risk"),
            dark_pattern=bool(result.get("dark_pattern_found")),
        )
        db.session.add(record)
        db.session.commit()
    except Exception:
        db.session.rollback()  # history logging is best-effort, never block the response

    return jsonify(result)


@app.route("/demo")
@login_required
def demo():
    """
    Returns analysis of a set of built-in demo texts (no image needed).
    """
    demo_texts = [
        "Only 2 rooms left at this price! Book now before it's gone.",
        "No thanks, I don't want to save money.",
        "Offer expires in 00:14:32 — act now!",
        "Your free trial ends today. Your card will be charged $9.99/month automatically.",
        "Price shown before taxes and service fees.",
        "This is a normal product page with no promotional content.",
    ]

    results = []
    for text in demo_texts:
        r = run_pipeline(image_input=None, raw_text=text, use_ocr=False)
        results.append(
            {
                "text":              text,
                "dark_pattern_found": r["dark_pattern_found"],
                "verdict":            r["verdict"],
                "overall_risk":       r["overall_risk"],
                "detections":         r["detections"],
                "summary":            r["summary"],
            }
        )

    return jsonify({"demo_results": results})


@app.route("/static/uploads/<filename>")
@login_required
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)


@app.route("/history")
@login_required
def history():
    records = (
        Analysis.query.filter_by(user_id=current_user.id)
        .order_by(Analysis.created_at.desc())
        .limit(50)
        .all()
    )
    return render_template("history.html", records=records, user=current_user)


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("  Pattern Audit  —  http://127.0.0.1:5000")
    print("=" * 60)
    app.run(debug=False, host="0.0.0.0", port=5000)
